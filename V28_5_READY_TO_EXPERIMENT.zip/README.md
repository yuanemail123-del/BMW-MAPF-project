# Warehouse Safety Simulator V28.5 Ready to Experiment

This is a **research-use candidate with partial technical acceptance**, not a fully certified or 33/33 validated build. The simulator engine is identical to the supplied V28.5 Candidate; only displayed branding changed.

Open `V28_5_READY_TO_EXPERIMENT.html` locally. The maps, task generation, rules and scoring are unchanged. Preserve source SHA256 and exported Scenario JSON for each formal paired experiment.

Acceptance has been revised: contacts do not have to equal zero, but rule activation, visible behavioral change, target interaction improvements, paired mission completion, and failure transparency are required. Do not assume every case shows improvement. See VALIDATION.md and QA_33_READY_MATRIX.csv.
