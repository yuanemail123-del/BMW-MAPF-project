# V28.5 Ready to Experiment — changelog

- Renamed HTML title/header and distributable to **V28.5 Ready to Experiment**.
- **No engine, rule, planning, scenario generation, scoring, or contact detection changes** from V28.5 Candidate.
- Updated technical acceptance definition: nonzero residual contacts are evaluative observations rather than automatic disqualification.
- Added a fresh randomized acceptance matrix with actual executed results separated from NOT_TESTED entries.
- Included a reproducible headless engine regression script and SHA256.
- Browser ZIP export and preference persistence were not retested in this run.
