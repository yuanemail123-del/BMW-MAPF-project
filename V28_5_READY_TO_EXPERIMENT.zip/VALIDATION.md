# V28.5 Ready to Experiment — technical validation

## Release disposition
**READY TO EXPERIMENT (conditional research-use label). NOT fully accepted as 33/33 validated.**

Same V28.5 engine as previous candidate. No software fixes were made in this release.

## Fresh random acceptance execution
- Actual complete paired execution results: **9 of 33**.
- Not executed/completed in this retest: **24 of 33**.
- All 9 recorded results show OFF/ON 80/80 mission completion, but rule-specific activation and collision/zone semantics need additional targeted evaluation.
- Setup: Mission Generator, 20 missions/agent, Task Seed 1001, Hazard Seed 1301, Low hazard density, same generated scenario in OFF/ON.
- E2-07: OFF→ON dynamic contact pair-steps **21→0**; Agent–Agent contact pair-steps **24→0**; coverage OFF **99.375%**, ON **99.543%**; both **80/80 COMPLETE**.
- E1-01–08: both paired arms **80/80 COMPLETE**, non-dynamic outcomes; rule events exist and paths differ, but these facts alone do not verify activation of the specific intended safety rule.

## Important evidence limitation
The harness collects the simulation engine outputs, not full browser user-interface interactions. No interactive ZIP download/localStorage regression has been repeated. The previous E1-10 SR-024 observation with **3 remaining ON dynamic pair-steps** is admissible evidence of partial collision reduction (21→3), but was not rerun as one of the 9 rows in this matrix. Residual contacts should be reported, not hidden.

## Acceptance recommendation
Start **pilot experiments and structured data collection**, but before calling data the final thesis dataset: finish or explicitly bound remaining E1/E2 cases, verify rule-specific triggering (especially SR-009/016/018/012), inspect same-scenario OFF/ON pairing, verify eight reports and browser controls, and preserve all failed runs.

## Definitions
`TECHNICAL_PASS_PROVISIONAL` = both tasks complete, events and path differences observed, basic contact metrics captured; **not** a full rule-by-rule efficacy proof. `NOT_TESTED` = no fresh complete run.
