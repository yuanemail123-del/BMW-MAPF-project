
'use strict';
const RULES=['SR-009','SR-016','SR-018','SR-024','SR-042','SR-012'];
const ALIAS={robotArea:'robotZone',forkliftArea:'forkliftZone',handoverBay:'bay',waitingZone:'wait',dynamicObstacle:'dynamic'};
const TYPES={R:'#35f5e3',FL:'#f9dc55',HW:'#ff91cd'};
const at=(x,y)=>[x,y],key=(p)=>p[0]+','+p[1],same=(a,b)=>!!a&&!!b&&a[0]===b[0]&&a[1]===b[1];
const VEC=[[1,0],[0,1],[-1,0],[0,-1]];
function mulberry32(a){return function(){let t=a+=0x6D2B79F5;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296;}}
function normalize(raw,id){if(!raw?.grid||!raw.layers)throw Error('Missing grid/layers.');let W=Number(raw.grid.width),H=Number(raw.grid.height);if(!Number.isInteger(W)||!Number.isInteger(H)||W<8||H<8||W*H>300000)throw Error('Invalid grid size');let layer={};for(const k of ['rack','wall','staticObstacle','robotZone','forkliftZone','bay','wait','robotOnly','crossing','parking1','parking2','dynamic'])layer[k]=new Set();for(let [k,v] of Object.entries(raw.layers)){let name=ALIAS[k]||k;if(!layer[name])continue;for(const p of v||[]){if(!Array.isArray(p)||p.length<2||!Number.isInteger(p[0])||!Number.isInteger(p[1])||p[0]<0||p[1]<0||p[0]>=W||p[1]>=H)throw Error(`Invalid ${k} cell ${JSON.stringify(p)}`);layer[name].add(key(p));}}
let obstacles=new Set([...layer.rack,...layer.wall,...layer.staticObstacle,...layer.parking1,...layer.parking2]);let issues=[];
for(const k of ['rack','staticObstacle','wall'])for(const p of layer[k])if(layer.bay.has(p))issues.push(`${k} inside bay: ${p}`);
let agents=(raw.agents||[]).map(a=>({id:String(a.id),type:a.type,initial:a.initial?.slice(),missions:(a.missions||[]).map(m=>({start:m.start.slice(),goal:m.goal.slice(),path:m.path||null})),startStep:Number(a.startStep||0)}));let seen=new Set();for(const a of agents){if(!['R','FL','HW'].includes(a.type))issues.push('Invalid type '+a.id);if(seen.has(a.id))issues.push('Duplicate ID '+a.id);seen.add(a.id);if(!a.initial||!validPoint({W,H},a.initial))issues.push('Invalid initial for '+a.id);a.missions.forEach((m,i)=>{if(i===0&&!same(m.start,a.initial))issues.push(`${a.id} initial differs from M1 start`);if(i&&!same(m.start,a.missions[i-1].goal))issues.push(`${a.id} M${i+1} chain discontinuity`);});}
let dyn=[];for(const d of [...(raw.dynamicObstacles||[]),...(raw.dynamicEvents||[])]){if(d.path?.length){dyn.push({id:d.id||'D'+dyn.length,start:Number(d.start??d.activation_step??0),path:d.path.map(p=>p.slice()),duration:d.duration==null?null:Number(d.duration),stepInterval:Number(d.stepInterval||2),repeatPeriod:d.repeatPeriod==null?null:Number(d.repeatPeriod)});}}
for(const xy of layer.dynamic){if(!dyn.some(d=>d.path.some(p=>key(p)===xy)))dyn.push({id:'D'+dyn.length,start:25+dyn.length*7,path:[xy.split(',').map(Number)],duration:null});}
return {id,W,H,cellSize:raw.grid.cell_size_m||0.5,layer,obstacles,agents,dyn,issues,raw};}
function validPoint(m,p){return !!p&&p[0]>=0&&p[0]<m.W&&p[1]>=0&&p[1]<m.H&&Number.isInteger(p[0])&&Number.isInteger(p[1]);}
function occupied(m,p){return !validPoint(m,p)||m.obstacles.has(key(p));}
function footprint(p,h,type){if(type!=='FL')return [p];let hor=h===0||h===2,w=hor?3:2,z=hor?2:3,c=[];for(let y=0;y<z;y++)for(let x=0;x<w;x++)c.push([p[0]+x,p[1]+y]);return c;}
function zoneAllowed(m,p,h,type){
 const cells=footprint(p,h,type);
 return cells.every(z=>type==='R'?(m.layer.robotZone.has(key(z))||m.layer.bay.has(key(z))):
 type==='FL'?(!m.layer.bay.has(key(z))&&!m.layer.wait.has(key(z))&&(!m.layer.forkliftZone.size||m.layer.forkliftZone.has(key(z)))):
 type==='HW'?(!m.layer.robotZone.has(key(z))||m.layer.bay.has(key(z))||m.layer.wait.has(key(z))):true);
}
function sweptCells(from,fh,to,th,type){
 const pts=[...footprint(from,fh,type),...footprint(to,th,type)];
 if(type==='FL'&&fh!==th){for(let y=0;y<3;y++)for(let x=0;x<3;x++)pts.push([from[0]+x,from[1]+y]);}
 return pts;
}
function allowed(m,p,h,type,strictZone=false){return footprint(p,h,type).every(z=>!occupied(m,z))&&(!strictZone||zoneAllowed(m,p,h,type));}
function footprintTouches(cells,points){return cells.some(z=>points.has(key(z)));}
function inflateCells(m,cells,radius=1){let out=new Set();for(const k of cells){let [x,y]=k.split(',').map(Number);for(let dx=-radius;dx<=radius;dx++)for(let dy=-radius;dy<=radius;dy++)if(validPoint(m,[x+dx,y+dy]))out.add(key([x+dx,y+dy]));}return out;}

function heap(){let arr=[];return {push(v){arr.push(v);let i=arr.length-1;while(i>0){let pa=(i-1)>>1;if(arr[pa].f<=v.f)break;arr[i]=arr[pa];i=pa;}arr[i]=v;},pop(){const r=arr[0],v=arr.pop();if(arr.length){let i=0;while(true){let l=i*2+1;if(l>=arr.length)break;let r2=l+1,b=r2<arr.length&&arr[r2].f<arr[l].f?r2:l;if(arr[b].f>=v.f)break;arr[i]=arr[b];i=b;}arr[i]=v;}return r;},get size(){return arr.length;}}}
function astar(m,start,goal,type,{zone=false,extra=null,banned=null,startHeading=1,goalHeading=null,escapeBanned=false,transitionOK=null}={}){
  if(!allowed(m,start,startHeading,type,zone))return null;
  const encode=(p,h)=>key(p)+','+(type==='FL'?h:0);
  const h0=type==='FL'?startHeading:0;
  const initial={p:start.slice(),h:h0,g:0,f:0,parent:null};
  const open=heap();open.push(initial);
  const dist=new Map([[encode(initial.p,initial.h),0]]);
  const heuristic=(p)=>Math.abs(p[0]-goal[0])+Math.abs(p[1]-goal[1]);
  let count=0;
  while(open.size&&count++<m.W*m.H*(type==='FL'?30:7)){
    const cur=open.pop(),ck=encode(cur.p,cur.h);
    if(cur.g!==dist.get(ck))continue;
    if(same(cur.p,goal)&&(goalHeading==null||cur.h===goalHeading)){
      let result=[];for(let n=cur;n;n=n.parent)result.push({p:n.p.slice(),h:n.h});return result.reverse();
    }
    let next=[];
    if(type==='FL'){
      // Forward and reverse are both legitimate forklift movements. Heading remains unchanged.
      for(const sign of [1,-1])next.push({p:[cur.p[0]+sign*VEC[cur.h][0],cur.p[1]+sign*VEC[cur.h][1]],h:cur.h,c:1+(sign<0?.12:0)});
      for(const h of [(cur.h+1)%4,(cur.h+3)%4])next.push({p:cur.p.slice(),h,c:1.3});
    }else for(const d of VEC)next.push({p:[cur.p[0]+d[0],cur.p[1]+d[1]],h:0,c:1});
    for(const n of next){
      if(!allowed(m,n.p,n.h,type,zone))continue;
      if(type==='FL'&&n.h!==cur.h){
        // Conservative discrete pivot: 3x3 bounding box for a 2x3 / 3x2 footprint.
        let cells=[];for(let dy=0;dy<3;dy++)for(let dx=0;dx<3;dx++)cells.push([cur.p[0]+dx,cur.p[1]+dy]);
        if(cells.some(q=>occupied(m,q)))continue;
      }
      if(banned){
        const currentOverlap=footprint(cur.p,cur.h,type).filter(q=>banned.has(key(q))).length;
        const nextOverlap=footprint(n.p,n.h,type).filter(q=>banned.has(key(q))).length;
        const sweptOverlap=sweptCells(cur.p,cur.h,n.p,n.h,type).filter(q=>banned.has(key(q))).length;
        // Agents ALREADY within a clearance margin may move out without getting trapped.
        // Egress never permits an increase in occupied forbidden cells. Outside => strict ban.
        if(!(escapeBanned&&currentOverlap>0&&nextOverlap<=currentOverlap)&&sweptOverlap>0)continue;
        if(escapeBanned&&currentOverlap>0&&nextOverlap>currentOverlap)continue;
      }
      if(transitionOK&&!transitionOK(cur,n,type))continue;
      if(extra&&!extra(n.p))continue;
      const overlapPenalty=(escapeBanned&&banned)?footprint(n.p,n.h,type).filter(q=>banned.has(key(q))).length*6:0;
      const cost=cur.g+n.c+overlapPenalty,k=encode(n.p,n.h);
      if(cost>=(dist.get(k)??Infinity))continue;
      dist.set(k,cost);
      open.push({p:n.p,h:n.h,g:cost,f:cost+heuristic(n.p),parent:cur});
    }
  }
  return null;
}
function adjacentRack(m,p){return VEC.some(d=>m.layer.rack.has(key([p[0]+d[0],p[1]+d[1]])));}
function semantic(m,p,type){let z=key(p);if(m.layer.bay.has(z))return 'bay';if(m.layer.wait.has(z))return 'wait';if(adjacentRack(m,p))return 'rack';if(type==='HW')return 'humanTransit';if(type==='FL')return 'forkliftTransit';return 'transit';}
// V28: permanent task-point validity is independent of safety-rule switches.
// Geometry uses the existing allowed()/footprint() definitions; movement rules remain unchanged.
function taskPointValid(m,p,h,type,final=false){
 if(!allowed(m,p,h,type,false))return false;
 const cells=footprint(p,h,type), all=(layer)=>cells.every(z=>m.layer[layer].has(key(z)));
 const none=(layer)=>cells.every(z=>!m.layer[layer].has(key(z)));
 if(type==='R')return all('robotZone')&&(!final||none('bay'));
 if(type==='FL')return all('forkliftZone')&&none('bay')&&none('wait');
 if(type==='HW')return cells.every(z=>m.layer.bay.has(key(z))||m.layer.wait.has(key(z)))&&(!final||all('wait'));
 return false;
}
function candidates(m,type,label,reference,final=false){
 let out=[];
 // Reference headings are preserved for FL; do not accept a centre-only footprint.
 const heading=(reference&&Number.isInteger(reference.heading))?reference.heading:1;
 for(let y=0;y<m.H;y++)for(let x=0;x<m.W;x++){
   const p=[x,y],k=key(p);
   if(!taskPointValid(m,p,heading,type,final))continue;
   if(label==='rack'&&!adjacentRack(m,p))continue;
   if(label==='bay'&&!m.layer.bay.has(k))continue;
   if(label==='wait'&&!m.layer.wait.has(k))continue;
   out.push(p);
 }
 return out;
}
// Experimental baseline diversity: a route may visit an accessible intermediate corridor cell
// without changing its start/goal. These routes are generated BEFORE the paired OFF/ON split.
function exploratoryBaseline(m,start,goal,type,startHeading,rng){
 const direct=astar(m,start,goal,type,{startHeading});
 if(!direct)return null;
 // Sample a waypoint outside this agent's authorized SR-009 zone. This is a
 // legitimate baseline route only if both pieces remain physically feasible.
 const wishes=[];
 for(let y=2;y<m.H-3;y+=2)for(let x=2;x<m.W-3;x+=2){
   const p=[x,y];if(!allowed(m,p,startHeading,type)||zoneAllowed(m,p,startHeading,type))continue;
   const extra=Math.abs(start[0]-x)+Math.abs(start[1]-y)+Math.abs(x-goal[0])+Math.abs(y-goal[1])-
          (Math.abs(start[0]-goal[0])+Math.abs(start[1]-goal[1]));
   if(extra>=1&&extra<Math.max(18,Math.floor(m.W*.6)))wishes.push({p,extra});
 }
 if(!wishes.length)return direct;
 // Prefer moderate corridor excursions; do not hardcode illegal or unconnected routes.
 wishes.sort((a,b)=>a.extra-b.extra);
 const shortlist=wishes.slice(0,Math.min(wishes.length,50));
 for(let k=0;k<Math.min(9,shortlist.length);k++){
   const cand=shortlist[Math.floor(rng()*shortlist.length)];
   const first=astar(m,start,cand.p,type,{startHeading});
   if(!first)continue;
   const second=astar(m,cand.p,goal,type,{startHeading:first.at(-1).h});
   if(!second)continue;
   return first.concat(second.slice(1));
 }
 return direct;
}
// V28.1: Reserve every agent's full terminal footprint BEFORE generating mission goals.
// These are input-validity constraints only and do not alter rule enforcement or routing.
function generatedScenario(m,templates,options){
 const rng=mulberry32(Number(options.seed)||1001);
 const ref=templates?.agents?.length?templates.agents:m.agents;
 const requested=options.agents||ref.map(a=>({id:a.id,type:a.type,count:4,startStep:0}));
 const agents=[],warnings=[];
 const fail=(code,detail)=>{throw Error('WORKFLOW_GENERATION_FAILED: '+code+' '+detail);};
 const intersects=(first,second)=>{const set=new Set(first.map(key));return second.some(p=>set.has(key(p)));};
 const initialStates=[],terminalStates=[];
 // Phase A: choose non-overlapping INITIAL footprints (including the entire 2x3 forklift body).
 for(const spec of requested){
   const type=spec.type,count=Number(spec.count);
   if(!Number.isInteger(count)||count<1||count>100)fail('INVALID_MISSION_COUNT',spec.id);
   let template=ref.find(a=>a.id===spec.id)||ref.find(a=>a.type===type);
   if(!template?.missions?.length)template=m.agents.find(a=>a.id===spec.id)||m.agents.find(a=>a.type===type&&a.missions?.length);
   if(!template?.missions?.length)fail('NO_TEMPLATE',spec.id);
   const original=m.agents.find(a=>a.id===spec.id)?.initial||template.initial;
   const heading=1;
   const freeStart=p=>taskPointValid(m,p,heading,type)&&initialStates.every(s=>!intersects(footprint(p,heading,type),s.cells));
   let initial=original?.slice();
   if(!initial||!freeStart(initial)){
     const pool=candidates(m,type,'transit',{heading}).filter(freeStart);
     if(!pool.length)fail('INITIAL_OCCUPANCY_CONFLICT',spec.id);
     pool.sort((a,b)=>{const da=(a[0]-(initial?.[0]||0))**2+(a[1]-(initial?.[1]||0))**2;
       const db=(b[0]-(initial?.[0]||0))**2+(b[1]-(initial?.[1]||0))**2;
       return da-db||a[1]-b[1]||a[0]-b[0];});
     initial=pool[0].slice();warnings.push('REPLACED_INVALID_EXPERIMENT_INITIAL '+spec.id);
   }
   initialStates.push({id:spec.id,cells:footprint(initial,heading,type)});
   agents.push({id:spec.id,type,initial,missions:[],startStep:Number(spec.startStep)||0});
 }
 // Phase B: reserve terminal parking states, with fixed terminal heading for FL.
 // Final parking may not overlap other final parking, nor any DIFFERENT agent initial.
 for(const a of agents){
   const heading=a.type==='FL'?1:0,label=a.type==='HW'?'wait':'transit';
   const pool=candidates(m,a.type,label,{heading},true);
   if(!pool.length)fail('NO_VALID_FINAL_PARKING',a.id);
   const feasible=p=>{
     if(same(p,a.initial))return false;
     const cells=footprint(p,heading,a.type);
     if(terminalStates.some(s=>intersects(cells,s.cells)))return false;
     if(initialStates.some(s=>s.id!==a.id&&intersects(cells,s.cells)))return false;
     // Validate arrival orientation and elementary baseline reachability.
     return !!astar(m,a.initial,p,a.type,{startHeading:1,...(a.type==='FL'?{goalHeading:heading}:{})});
   };
   let selected=null;
   const examined=new Set();
   for(let attempt=0;attempt<Math.min(100,pool.length);attempt++){
     const p=pool[Math.floor(rng()*pool.length)];if(examined.has(key(p)))continue;
     examined.add(key(p));if(feasible(p)){selected=p;break;}
   }
   if(!selected){
     const remain=pool.filter(p=>!examined.has(key(p))).sort((p,q)=>
       Math.abs(p[0]-a.initial[0])+Math.abs(p[1]-a.initial[1])-
       Math.abs(q[0]-a.initial[0])-Math.abs(q[1]-a.initial[1])||p[1]-q[1]||p[0]-q[0]);
     for(const p of remain){if(feasible(p)){selected=p;break;}}
   }
   if(!selected)fail('NO_VALID_FINAL_PARKING',a.id+' terminal footprint unavailable');
   a._terminal={p:selected.slice(),h:heading};
   terminalStates.push({id:a.id,cells:footprint(selected,heading,a.type)});
 }
 // Phase C: generate each mission while protecting EVERY OTHER agent's reserved footprint.
 for(const a of agents){
   const spec=requested.find(z=>z.id===a.id),type=a.type,count=Number(spec.count);
   const template=ref.find(z=>z.id===a.id)||ref.find(z=>z.type===type)||m.agents.find(z=>z.type===type);
   const roles=template.missions.map(z=>semantic(templates||m,z.goal,type));
   const protectedCells=new Set(terminalStates.filter(s=>s.id!==a.id).flatMap(s=>s.cells.map(key)));
   const goalClear=(p,h)=>footprint(p,h,type).every(q=>!protectedCells.has(key(q)));
   let cur=a.initial.slice(),heading=1;
   const basePools=new Map();
   for(let i=0;i<count;i++){
     let label=roles[i%roles.length];const last=i===count-1;
     if(last)label=type==='HW'?'wait':'transit';
     if(type==='FL'&&(label==='bay'||label==='wait'||label==='humanTransit'))label='forkliftTransit';
     if(type==='HW'&&label!=='bay'&&label!=='wait')label='bay';
     const ck=[type,label,heading,last].join('|');
     if(!basePools.has(ck))basePools.set(ck,candidates(m,type,label,{heading},last));
     let pool=basePools.get(ck);
     if(last)pool=[a._terminal.p];
     if(!pool.length)fail(last?'NO_VALID_FINAL_PARKING':'NO_LEGAL_GOAL',a.id+' M'+(i+1)+' '+label);
     let chosen=null,headingOut=heading;
     const examined=new Set();
     function consider(p){
       if(same(p,cur)||!goalClear(p,last?a._terminal.h:heading))return null;
       let path=astar(m,cur,p,type,{startHeading:heading,...(last&&type==='FL'?{goalHeading:a._terminal.h}:{})});
       if(!path)return null;
       let arrival=path.at(-1).h;
       if(!goalClear(p,arrival)||!taskPointValid(m,p,arrival,type,last))return null;
       if(options.exploreZones!==false&&i<2&&!last){
         const diversified=exploratoryBaseline(m,cur,p,type,heading,rng);
         if(diversified&&goalClear(p,diversified.at(-1).h)&&taskPointValid(m,p,diversified.at(-1).h,type))path=diversified;
       }
       return {start:cur.slice(),goal:p.slice(),path};
     }
     for(let n=0;n<Math.min(pool.length,100);n++){
       const p=pool[Math.floor(rng()*pool.length)],kp=key(p);if(examined.has(kp))continue;examined.add(kp);
       const result=consider(p);if(result){chosen=result;headingOut=result.path.at(-1).h;break;}
     }
     if(!chosen){
       const sorted=pool.filter(p=>!examined.has(key(p))&&!same(p,cur)).sort((p,q)=>
         Math.abs(p[0]-cur[0])+Math.abs(p[1]-cur[1])-Math.abs(q[0]-cur[0])-Math.abs(q[1]-cur[1])||p[1]-q[1]||p[0]-q[0]);
       for(const p of sorted){const result=consider(p);if(result){chosen=result;headingOut=result.path.at(-1).h;break;}}
     }
     if(!chosen)fail(last?'NO_VALID_FINAL_PARKING':'NO_GEOMETRIC_ROUTE',a.id+' M'+(i+1)+' '+label);
     if(!taskPointValid(m,chosen.start,heading,type)||!taskPointValid(m,chosen.goal,headingOut,type,last)||!goalClear(chosen.goal,headingOut))
       fail('TASK_POINT_VALIDATION_FAILED',a.id+' M'+(i+1));
     a.missions.push(chosen);cur=chosen.goal.slice();heading=headingOut;
   }
   if(a.missions.length!==count||!same(a.initial,a.missions[0].start))fail('WORKFLOW_CHAIN_BROKEN',a.id);
   if(!same(cur,a._terminal.p)||heading!==a._terminal.h)fail('TERMINAL_HEADING_MISMATCH',a.id);
   delete a._terminal;
 }
 return{agents,warnings,seed:options.seed,templateId:templates?.id||m.id};
}

function scenarioFromValidation(m,startTimes={}){let warnings=[],agents=m.agents.map(a=>{let missions=[],i=0,heading=1;for(const v of a.missions){if(!same(i?missions[i-1].goal:a.initial,v.start)){warnings.push(a.id+' discontinuous');break;}let path=astar(m,v.start,v.goal,a.type,{startHeading:heading});if(!path){warnings.push('RECONSTRUCTED_BASELINE '+a.id+' M'+(i+1));path=astar(m,v.start,v.goal,a.type,{startHeading:heading});}if(!path)warnings.push('NO_VALID_PATH '+a.id+' M'+(i+1));missions.push({start:v.start,goal:v.goal,path,unreachable:!path});if(path)heading=path.at(-1).h;i++;}return {...a,startStep:Number(startTimes[a.id]??a.startStep??0),missions};});for(const a of agents){if(['R','HW'].includes(a.type)&&a.missions.length&&inArea(m,a.missions.at(-1).goal,'bay'))warnings.push('VALIDATION_FINAL_BAY_OCCUPANCY '+a.id+' (user mission unchanged)');}
return {agents,warnings,seed:0,templateId:m.id};}
const hasFoot=(agents,p)=>agents.some(f=>f.some(q=>same(q,p)));
// V28.4: finite events repeat on a frozen absolute timeline, independently of agent progress.
// Imported legacy hazards without repeatPeriod retain their exact historical semantics.
function dynamicPos(m,t){return m.dyn.map(d=>{
 const phase=t-d.start,cycle=d.repeatPeriod>0?phase%d.repeatPeriod:phase;
 if(phase<0||(d.duration!=null&&cycle>=d.duration))return null;
 const path=d.path||[];if(!path.length)return null;
 const steps=Math.floor(cycle/Math.max(1,d.stepInterval||2));
 const period=Math.max(1,2*(path.length-1)),i=steps%period;
 return {...d,p:path[i<path.length?i:period-i]};
}).filter(Boolean);}
function pairContacts(states){let out=[];for(let i=0;i<states.length;i++)for(let j=i+1;j<states.length;j++)if(states[i].foot.some(p=>states[j].foot.some(q=>same(p,q))))out.push({a:states[i].id,b:states[j].id,p:states[i].p});return out;}
function inArea(m,p,l){return m.layer[l].has(key(p));}
function safetyViolation(rule,m,s,dyn,contacts){
 if(!s.active)return false;
 if(rule==='SR-009')return !zoneAllowed(m,s.p,s.h,s.type);
 if(rule==='SR-016')return footprintTouches(s.foot,m.layer.staticObstacle);
 if(rule==='SR-018')return footprintTouches(s.foot,inflateCells(m,m.layer.staticObstacle,1));
 if(rule==='SR-024')return dyn.some(d=>s.foot.some(f=>same(d.p,f)));
 if(rule==='SR-042')return contacts.some(c=>c.a===s.id||c.b===s.id);
 if(rule==='SR-012')return ['R','HW'].includes(s.type)&&inArea(m,s.p,'bay')&&contacts.some(c=>c.a===s.id||c.b===s.id);
 return false;
}
function statesBayOverlap(m,s,contacts){return inArea(m,s.p,'bay')&&contacts.some(c=>(c.a===s.id||c.b===s.id)&&[c.a,c.b].some(x=>x.startsWith('HW')));}
function simulate(m,scenario,rules,on,opts){
 const selected=Array.isArray(rules)?[...new Set(rules)]:[rules],enabled=on?selected:[];
 // Rack/wall/parking stay physically solid in both arms. Only experiment-designated
 // 1x1 static hazards are penetrable in OFF to measure model-level contact.
 const baselineMap={...m,obstacles:new Set([...m.obstacles].filter(k=>!m.layer.staticObstacle.has(k)))};
 const TS=Math.max(.01,Number(opts.TS)||1),weights=opts.weights||{R:8,C:25,O:.12,W:.45};
 const qR=Number(opts.qR??1),qC=Number(opts.qC??1);
 const horizonSafety=Math.max(6000,scenario.agents.reduce((n,a)=>n+a.missions.reduce((z,k)=>z+(k.path?.length||140)*12,0),0)+4000);
 const rstate=scenario.agents.map(a=>({...a,p:a.initial.slice(),h:a.initialHeading??1,mi:0,idx:0,done:0,route:null,detour:null,wait:0,travel:0,status:'NOT_STARTED',flag:'',replans:0,failed:false,waitCause:null,backsteps:0,trafficHold:0,blockedSince:0,stalled:0,blockedBy:[]}));
 let frames=[],events=[],cum={R:0,C:0,O:0,W:0},prevContacts=new Set(),lastProgress=0,termination='',reservations={bay:null};
 const report=(t,id,type,description,pos)=>events.push({t,id,type,description,pos:pos?.slice()});
 const toFoot=(s,n)=>footprint(n.p,n.h??s.h,s.type);
 const intersects=(a,b)=>a.some(x=>b.some(y=>same(x,y)));
 const goalOf=s=>s.missions[s.mi]?.goal;
 const waypoint=(s)=>s.detour||s.route;
 const makeRoute=(s,banned=null,zone=false,goal=null,escapeBanned=false)=>astar(baselineMap,s.p,goal||goalOf(s),s.type,{
  startHeading:s.h,zone,
  // All static rule admission decisions are checked on edges by the same predicate as the executor.
  // Non-clearance bans still use the original grid restrictions.
  banned:(s.type==='R'&&escapeBanned)?null:banned,
  escapeBanned:(s.type==='R'&&escapeBanned)?false:escapeBanned,
  transitionOK:(from,to)=>clearanceTransitionOK(s.type,from,to)
 });
 // All spatial safety functions operate on the full agent footprint, not solely the route anchor.
 const routeValid=(s,path)=>Array.isArray(path)&&path.length>0&&same(path[0].p,s.p)&&path[0].h===s.h&&path.every((n,i)=>{
   if(!allowed(baselineMap,n.p,n.h,s.type))return false;
   if(i===0)return true;
   const before=path[i-1],dx=Math.abs(before.p[0]-n.p[0]),dy=Math.abs(before.p[1]-n.p[1]);
   if(dx+dy>1||(dx+dy===1&&before.h!==n.h))return false;
   if(s.type==='FL'&&before.h!==n.h&&sweptCells(before.p,before.h,n.p,n.h,s.type).some(p=>occupied(baselineMap,p)))return false;
   return true;
 });
 // V28.3 SR-024 Candidate: no additional grid-clearance inflation.
 // SR-016 and SR-018 are reduced-scope global-occupancy proxies; see VALIDATION.md.
 // Only real occupied cells and the full swept footprint are prohibited.
 const staticHazardBuffer=new Set(m.layer.staticObstacle);
 const corridorBuffer=new Set([...m.layer.wall,...m.layer.staticObstacle]);
 const clearanceTransitionOK=(type,from,to)=>{
   if(!(enabled.includes('SR-016')||enabled.includes('SR-018')))return true;
   return !sweptCells(from.p,from.h,to.p,to.h,type).some(p=>m.layer.staticObstacle.has(key(p)));
 };

 const forbiddenAt=(s,cells)=>footprintTouches(sweptCells(s.p,s.h,s.proposal.p,s.proposal.h,s.type),cells);
 const overlapCount=(p,h,type,cells)=>footprint(p,h,type).filter(z=>cells.has(key(z))).length;
 const egressMove=(s,cells)=>{
   const before=overlapCount(s.p,s.h,s.type,cells),after=overlapCount(s.proposal.p,s.proposal.h,s.type,cells);
   return before>0&&after<=before&&
     !footprintTouches(sweptCells(s.p,s.h,s.proposal.p,s.proposal.h,s.type),m.layer.staticObstacle);
 };
 // An existing buffer violation may be exited; re-entry and worse violations remain blocked.
 const staticMustBlock=(s,cells)=>forbiddenAt(s,cells)&&!egressMove(s,cells);
 const spatialReplan=(t,s,rule,banned)=>{
   const path=makeRoute(s,banned,enabled.includes('SR-009'),null,rule==='SR-016'||rule==='SR-018');
   if(path&&setRoute(t,s,path,'REPLAN '+rule+' FULL_FOOTPRINT')){s.proposal=s.route[1]||s.proposal;return true;}
   s.proposal={p:s.p.slice(),h:s.h};s.waitCause='NO_SAFE_PATH '+rule;return false;
 };
 const setRoute=(t,s,path,why,detour=false)=>{
   if(!path||!path.length)return false;
   if(detour){s.detour={path:path.map(n=>({p:n.p.slice(),h:n.h})),idx:0,reason:why};}
   else{s.route=path.map(n=>({p:n.p.slice(),h:n.h}));s.idx=0;s.detour=null;}
   s.replans++;report(t,s.id,detour?'RETREAT_OR_WAIT_ROUTE':'REPLAN',why,s.p);return true;
 };
 const nearestWait=(s)=>{
   let options=[...m.layer.wait].map(k=>k.split(',').map(Number));
   options.sort((a,b)=>(Math.abs(s.p[0]-a[0])+Math.abs(s.p[1]-a[1]))-(Math.abs(s.p[0]-b[0])+Math.abs(s.p[1]-b[1])));
   for(const p of options.slice(0,90)){
     if(!allowed(m,p,s.h,s.type))continue;
     const path=makeRoute(s,null,false,p);
     if(path&&path.length)return path;
   }
   return null;
 };
 const dynamicBanned=(dyn)=>new Set(dyn.map(d=>key(d.p)));
 const agentBanned=(members,excluded)=>new Set(members.filter(a=>a.id!==excluded).flatMap(a=>a.foot.map(key)));
 const standable=(s,p,others,dyn)=>allowed(m,p,s.h,s.type)&&!intersects(footprint(p,s.h,s.type),others.filter(a=>a.id!==s.id).flatMap(a=>a.foot))&&!dyn.some(d=>footprint(p,s.h,s.type).some(f=>same(f,d.p)));
 const retreatPlan=(s,others,dyn)=>{
   // Search a short, collision-free path to an unoccupied refuge away from both the encounter and the narrow corridor.
   const obstacles=new Set([...agentBanned(others,s.id),...dynamicBanned(dyn)]);
   const q=[{p:s.p.slice(),dist:0}],seen=new Set([key(s.p)]);
   let choices=[];
   for(let i=0;i<q.length&&i<180;i++){
     const n=q[i];if(n.dist>9)break;
     const clearance=VEC.reduce((sum,v)=>sum+Number(allowed(m,[n.p[0]+v[0],n.p[1]+v[1]],s.h,s.type)),0);
     if(n.dist>=1&&clearance>=3&&standable(s,n.p,others,dyn))choices.push(n);
     for(const v of VEC){const p=[n.p[0]+v[0],n.p[1]+v[1]],k=key(p);if(seen.has(k)||!allowed(m,p,s.h,s.type)||obstacles.has(k))continue;seen.add(k);q.push({p,dist:n.dist+1});}
   }
   choices.sort((a,b)=>a.dist-b.dist);
   for(const choice of choices.slice(0,12)){const path=makeRoute(s,obstacles,false,choice.p);if(path&&path.length>1)return {path,cost:path.reduce((n,x,i)=>n+(i&&!same(x.p,path[i-1].p)?1:0),0)};}
   return null;
 };
 const collisionCandidates=(A,B)=>intersects(toFoot(A,A.proposal),toFoot(B,B.proposal))||
   (intersects(toFoot(A,A.proposal),footprint(B.p,B.h,B.type))&&intersects(toFoot(B,B.proposal),footprint(A.p,A.h,A.type)));
 const doneOrFailed=()=>rstate.every(s=>s.failed||s.done>=s.missions.length); 
 // V27.1 rule coordinator: shared transition predicate, time-aware dynamic search,
 // conflict-group arbitration, and atomic proposal selection.
 class CentralizedRuleCoordinator {
   constructor(){this.previousCycles=new Set();this.waitGraph=new Map();}
   active(s,t){return t>=s.startStep&&!s.failed&&(s.done<s.missions.length||enabled.includes('SR-024'));}
   node(s){return {p:s.p.slice(),h:s.h};}
   countIn(p,h,type,cells){return footprint(p,h,type).filter(c=>cells.has(key(c))).length;}
   evaluateTransition(s,from,to,t,others=null,ignoreTraffic=false){
     const faults=[],blocking=[],affected=[];
     const sweep=sweptCells(from.p,from.h,to.p,to.h,s.type);
     // L0: immutable rack/wall/boundary/parking; forklift 3x3 turning sweep.
     for(const cell of sweep)if(occupied(baselineMap,cell)){faults.push('PHYSICAL_GEOMETRY');affected.push(key(cell));break;}
     if(enabled.includes('SR-009')&&!zoneAllowed(m,to.p,to.h,s.type)){
       // Agent already outside the allowed zone may take physically valid egress
       // only if it decreases its *own* unauthorized footprint occupancy.
       const a=footprint(from.p,from.h,s.type).filter(c=>!zoneCellAllowed(c,s.type)).length;
       const b=footprint(to.p,to.h,s.type).filter(c=>!zoneCellAllowed(c,s.type)).length;
       if(!(a>0&&b<a))faults.push('ZONE_RESTRICTED');
     }
     if(enabled.includes('SR-016')||enabled.includes('SR-018')){
       // Physical static obstacle body blocks every agent; rule-specific clearance belongs to R.
       if(sweep.some(c=>m.layer.staticObstacle.has(key(c))))faults.push('STATIC_CONTACT');
      }
     // No proximity buffer is enforced. Physical geometry and static occupancy
     // are already checked above, including full forklift swept footprint.
     if(enabled.includes('SR-024')){
       const hazards0=dynamicPos(m,t),hazards1=dynamicPos(m,t+1);
       // Time indexed end footprint and swept edge exchange; do not combine
       // all future hazard positions into a permanent forbidden set.
       const end=footprint(to.p,to.h,s.type),before=footprint(from.p,from.h,s.type);
       if(hazards1.some(d=>end.some(c=>same(c,d.p)))||
          hazards0.some(d=>hazards1.some(e=>e.id===d.id&&end.some(c=>same(c,d.p))&&before.some(c=>same(c,e.p)))))
          faults.push('DYNAMIC_OCCUPANCY_BLOCKED');
       // During an actual forklift turn, reject a moving hazard inside the swept region.
       if(from.h!==to.h&&s.type==='FL'&&hazards1.some(d=>sweep.some(c=>same(c,d.p))))faults.push('DYNAMIC_SWEEP');
     }
     if(enabled.includes('SR-012')&&['R','HW'].includes(s.type)&&footprint(to.p,to.h,s.type).some(c=>inArea(m,c,'bay'))){
       const enemy=(others||rstate).filter(o=>o.id!==s.id&&['R','HW'].includes(o.type)&&o.type!==s.type&&
         footprint(o.p,o.h,o.type).some(c=>inArea(m,c,'bay')));
       if(enemy.length){faults.push('BAY_RESOURCE_OCCUPIED');blocking.push(...enemy.map(o=>o.id));}
     }
     return {valid:!faults.length,violatedConstraints:[...new Set(faults)],blockingAgents:blocking,affectedCells:affected,
       reasonCode:faults[0]||'OK'};
   }
   conflicts(s,a,o,b){
     const fa=footprint(a.p,a.h,s.type),fb=footprint(b.p,b.h,o.type);
     if(intersects(fa,fb))return true;
     const pa=footprint(s.p,s.h,s.type),pb=footprint(o.p,o.h,o.type);
     if(intersects(fa,pb)&&intersects(fb,pa))return true;
     // Pivot swept footprint may overlap the other vehicle's swept envelope.
     if(s.type==='FL'&&a.h!==s.h&&intersects(sweptCells(s.p,s.h,a.p,a.h,s.type),fb))return true;
     if(o.type==='FL'&&b.h!==o.h&&intersects(sweptCells(o.p,o.h,b.p,b.h,o.type),fa))return true;
     return false;
   }
   pathSignature(s,t,reason){return [s.mi,key(s.p),s.h,key(goalOf(s)||s.p),[...enabled].sort().join(','),
     [...rstate.filter(x=>x.id!==s.id).flatMap(x=>footprint(x.p,x.h,x.type).map(key))].sort().join(';'),
     enabled.includes('SR-024')?dynamicPos(m,t+1).map(d=>d.id+':'+key(d.p)).sort().join(';'):'',reason].join('|');}
   recordFailure(t,s,reason){
     const sig=this.pathSignature(s,t,reason);
     if(s.lastRejectedSignature!==sig){s.lastRejectedSignature=sig;report(t,s.id,'REPEATED_REJECTED_PATH',reason+' @'+key(s.p)+' M'+(s.mi+1),s.p);}
   }
   // Temporal local search. Searches (position, heading, time) and includes WAIT.
   // Returns a short valid time-indexed prefix; the normal route continues after
   // the obstacle clears. Never permanently blocks future patrol cells.
   temporalPlan(s,t,limit=11){
     const start={p:s.p.slice(),h:s.h,dt:0,g:0,parent:null};
     const q=[start],seen=new Set([key(s.p)+'|'+s.h+'|0']);
     const heuristic=p=>Math.abs(p[0]-goalOf(s)[0])+Math.abs(p[1]-goalOf(s)[1]);
     let best=start,bestScore=heuristic(start.p),visited=0;
     while(q.length&&visited++<4800){
       const cur=q.shift();
       if(cur.dt>=limit)continue;
       const dirs=s.type==='FL'?[{p:[cur.p[0]+VEC[cur.h][0],cur.p[1]+VEC[cur.h][1]],h:cur.h},
         {p:[cur.p[0]-VEC[cur.h][0],cur.p[1]-VEC[cur.h][1]],h:cur.h},
         {p:cur.p.slice(),h:(cur.h+1)%4},{p:cur.p.slice(),h:(cur.h+3)%4},{p:cur.p.slice(),h:cur.h}]:
         [...VEC.map(d=>({p:[cur.p[0]+d[0],cur.p[1]+d[1]],h:cur.h})),{p:cur.p.slice(),h:cur.h}];
       for(const n of dirs){const nt=t+cur.dt;const test=this.evaluateTransition(s,cur,n,nt,rstate,true);
         if(!test.valid)continue;
         const id=key(n.p)+'|'+n.h+'|'+(cur.dt+1);if(seen.has(id))continue;seen.add(id);
         const candidate={p:n.p,h:n.h,dt:cur.dt+1,parent:cur};q.push(candidate);
         const score=heuristic(candidate.p)+candidate.dt*.15;
         if(score<bestScore-.001){best=candidate;bestScore=score;}
         if(same(n.p,goalOf(s))){best=candidate;q.length=0;break;}
       }
     }
     if(best===start)return null;
     let result=[];for(let z=best;z;z=z.parent)result.push({p:z.p.slice(),h:z.h});return result.reverse();
   }
   replan(s,t,reason,blockedAgents=[]){
     const sig=this.pathSignature(s,t,reason);
     if(s.failedReplanSignature===sig)return null;
     // Use the SAME geometry/zone/static constraints as the execution evaluator.
     const forbidden=new Set();
     // Static bodies are physically solid for the ON arm; margins are checked by
     // the same transition predicate as evaluateTransition, including legal egress.
     if(enabled.includes('SR-016')||enabled.includes('SR-018'))for(const x of m.layer.staticObstacle)forbidden.add(x);
     // Pre-planned tracks of competing agents are NOT permanent static barriers:
     // only currently stationary blocker footprints may be excluded.
     for(const o of blockedAgents)for(const c of footprint(o.p,o.h,o.type))forbidden.add(key(c));
     let route=astar(baselineMap,s.p,goalOf(s),s.type,{startHeading:s.h,zone:enabled.includes('SR-009'),
       banned:forbidden.size?forbidden:null,escapeBanned:false,
       transitionOK:(from,to)=>clearanceTransitionOK(s.type,from,to)});
     // SR-024: a conflict at a FUTURE time is not a permanent path barrier.
     // Preserve the static A* route, and evaluate the next action at its actual step.
     // A temporary conflict at the first step is handled by WAIT in proposeActions.
     if(!route && enabled.includes('SR-024'))route=this.temporalPlan(s,t);
     if(route&&route.length>1){
       const first=this.evaluateTransition(s,{p:s.p,h:s.h},route[1],t,rstate,true);
       if(first.valid || (enabled.includes('SR-024') && first.violatedConstraints.length &&
         first.violatedConstraints.every(x=>x==='DYNAMIC_OCCUPANCY_BLOCKED'||x==='DYNAMIC_SWEEP'))){
         s.failedReplanSignature=null;return route;
       }
     }
     s.failedReplanSignature=sig;this.recordFailure(t,s,reason);return null;
   }
   // For an approaching obstacle, waiting is not an automatically safe fallback.
   // Evaluate complete footprint at t+1 and select a legal one-step escape.
   safeDynamicEscape(s,t){
     if(!this.active(s,t))return null;
     const origin=this.node(s),candidates=[];
     if(s.type==='FL'){
       for(const k of [1,-1])candidates.push({p:[origin.p[0]+k*VEC[origin.h][0],origin.p[1]+k*VEC[origin.h][1]],h:origin.h});
       candidates.push({p:origin.p.slice(),h:(origin.h+1)%4},{p:origin.p.slice(),h:(origin.h+3)%4});
     }else for(const v of VEC)candidates.push({p:[origin.p[0]+v[0],origin.p[1]+v[1]],h:origin.h});
     let best=null,score=Infinity;
     for(const c of candidates){
       if(!this.evaluateTransition(s,origin,c,t,rstate,true).valid)continue;
       const conflicting=rstate.some(o=>o.id!==s.id&&t>=o.startStep&&
         this.conflicts(s,c,o,this.node(o)));
       if(conflicting)continue;
       const goal=goalOf(s)||s.p;const delta=Math.abs(c.p[0]-goal[0])+Math.abs(c.p[1]-goal[1]);
       // Prefer a cell that also has a safe follow-up WAIT, but allow retreat.
       const futureSafe=this.evaluateTransition(s,c,c,t+1,rstate,true).valid;
       const cost=delta+(futureSafe?0:20);
       if(cost<score){best=c;score=cost;}
     }
     if(best){s.route=null;s.detour=null;s.idx=0;}
     return best;
   }
   // Post-mission safety remains active: completion does not remove physical occupancy.
   // Keep mission counters frozen, only make a legal protective move when hazards approach.
   safePostMission(s,t){
     if(!enabled.includes('SR-024'))return null;
     const origin=this.node(s);
     const risk=(node,k)=>dynamicPos(m,t+k).some(d=>footprint(node.p,node.h,s.type).some(c=>same(c,d.p)));
     if(![1,2,3,4,5,6,7,8].some(k=>risk(origin,k)))return null;
     const options=[];
     if(s.type==='FL'){
       for(const k of [1,-1])options.push({p:[origin.p[0]+k*VEC[origin.h][0],origin.p[1]+k*VEC[origin.h][1]],h:origin.h});
       options.push({p:origin.p.slice(),h:(origin.h+1)%4},{p:origin.p.slice(),h:(origin.h+3)%4});
     }else for(const v of VEC)options.push({p:[origin.p[0]+v[0],origin.p[1]+v[1]],h:origin.h});
     let best=null,score=-Infinity;
     for(const next of options){
       if(!this.evaluateTransition(s,origin,next,t,rstate,true).valid)continue;
       if(rstate.some(o=>o.id!==s.id&&t>=o.startStep&&this.conflicts(s,next,o,this.node(o))))continue;
       let safeSteps=0;for(let k=1;k<=8;k++){if(risk(next,k))break;safeSteps++;}
       const moved=!same(next.p,origin.p),turned=next.h!==origin.h;
       const value=safeSteps*10-(turned?1:0)-(moved?2:0);
       if(value>score){score=value;best=next;}
     }
     return best&&score>=10?best:null;
   }
   proposeActions(t,snapshot){
     const proposals=new Map(),waits=new Map(),blockers=new Map();
     for(const s of rstate){
       s.flag='';const stay=this.node(s);proposals.set(s.id,stay);blockers.set(s.id,[]);
       if(t<s.startStep){s.status='NOT_STARTED';continue;}
       if(s.failed){s.status='INFEASIBLE';continue;}
       if(s.done>=s.missions.length){
         s.status='COMPLETE';
         if(enabled.includes('SR-024')){
           const park=this.safePostMission(s,t);
           if(park){proposals.set(s.id,park);s.flag='POST_MISSION_SAFE_EGRESS';}
         }
         continue;
       }
       if(!s.missions.length){s.failed=true;report(t,s.id,'INFEASIBLE','No missions',s.p);continue;}
       // A staging detour is a temporary action route and never changes the goal.
       if(s.detour&&s.detour.idx>=s.detour.path.length-1)s.detour=null;
       if(!s.route||(!s.detour&&s.idx>=s.route.length-1&&!same(s.p,goalOf(s)))||!same(s.route[s.idx]?.p,s.p)||s.route[s.idx]?.h!==s.h){
         const path=this.replan(s,t,'INITIAL_OR_STALE_ROUTE');
         if(path){setRoute(t,s,path,'COORDINATOR ROUTE');}
         else if(!s.route){
           // Certify basic geometric infeasibility separately from temporary
           // reservations or moving hazards; do not misreport these as deadlock.
           const physical=astar(baselineMap,s.p,goalOf(s),s.type,{startHeading:s.h});
           if(!physical){s.failed=true;s.status='INFEASIBLE';report(t,s.id,'INFEASIBLE','NO_GEOMETRIC_PATH M'+(s.mi+1),s.p);}
           else if(enabled.includes('SR-009')&&!zoneAllowed(m,goalOf(s),s.h,s.type)){
             s.failed=true;s.status='INFEASIBLE';report(t,s.id,'INFEASIBLE','ZONE_RESTRICTED_GOAL',s.p);
           }
           else waits.set(s.id,'NO_SAFE_PATH');
           continue;
         }
       }
       let path=s.detour?.path||s.route;
       const ix=s.detour?s.detour.idx:s.idx;
       const next=path?.[Math.min(ix+1,path.length-1)];
       if(!next){waits.set(s.id,'NO_ROUTE_NODE');continue;}
       let verdict=this.evaluateTransition(s,stay,next,t,snapshot,true);
       if(enabled.includes('SR-024')&&verdict.valid){
         const currentRisk=[1,2,3,4].some(k=>dynamicPos(m,t+k).some(d=>
           footprint(stay.p,stay.h,s.type).some(c=>same(c,d.p))));
         const nextRisk=[1,2,3].some(k=>dynamicPos(m,t+k).some(d=>
           footprint(next.p,next.h,s.type).some(c=>same(c,d.p))));
         if(currentRisk&&nextRisk){const escape=this.safeDynamicEscape(s,t);
           if(escape){proposals.set(s.id,escape);continue;}}
       }
       if(!verdict.valid){
         // A finite transient hazard is time-dependent: keep the valid global route
         // and wait for its release instead of repeatedly discarding/replanning it.
         // The next step will be reevaluated against the updated hazard positions.
         if(enabled.includes('SR-024') && verdict.violatedConstraints.length &&
           verdict.violatedConstraints.every(x=>x==='DYNAMIC_OCCUPANCY_BLOCKED'||x==='DYNAMIC_SWEEP')){
           const waitCheck=this.evaluateTransition(s,stay,stay,t,snapshot,true);
           if(!waitCheck.valid){
             const escape=this.safeDynamicEscape(s,t);
             if(escape){proposals.set(s.id,escape);waits.delete(s.id);continue;}
             waits.set(s.id,'UNSAFE_WAIT_NO_ESCAPE');
           }else waits.set(s.id,verdict.reasonCode);
           blockers.set(s.id,verdict.blockingAgents);
           continue;
         }
         const newPath=this.replan(s,t,verdict.reasonCode);
         if(newPath){setRoute(t,s,newPath,'COORDINATOR REPLAN '+verdict.reasonCode);path=s.route;verdict=this.evaluateTransition(s,stay,path[1],t,snapshot,true);
           if(verdict.valid){proposals.set(s.id,{...path[1]});continue;}}
         waits.set(s.id,verdict.reasonCode);blockers.set(s.id,verdict.blockingAgents);
       }else proposals.set(s.id,{p:next.p.slice(),h:next.h});
     }
     return {proposals,waits,blockers};
   }
   jointValidate(t,proposals,waits,blockers,snapshot){
     const active=rstate.filter(s=>this.active(s,t));
     // The entire set is evaluated before any physical position is committed.
     // Conditional resource rules may depend on the peers' approved positions.
     for(let pass=0;pass<Math.max(2,active.length*2);pass++){
       let changed=false;
       for(const s of active){const n=proposals.get(s.id)||this.node(s);
         const check=this.evaluateTransition(s,this.node(s),n,t,rstate,true);
         if(!check.valid){
           const stay=this.node(s);
           const stayLegal=this.evaluateTransition(s,stay,stay,t,rstate,true).valid;
           const escape=!stayLegal&&enabled.includes('SR-024')?this.safeDynamicEscape(s,t):null;
           proposals.set(s.id,escape||stay);
           waits.set(s.id,escape?'DYNAMIC_SAFE_EGRESS':stayLegal?check.reasonCode:'UNSAFE_WAIT_NO_ESCAPE');
           blockers.set(s.id,check.blockingAgents);changed=true;
         }
       }
       if(enabled.includes('SR-012'))for(const s of active.filter(x=>['R','HW'].includes(x.type))){
         const n=proposals.get(s.id);if(!footprint(n.p,n.h,s.type).some(p=>inArea(m,p,'bay')))continue;
         const conflicting=rstate.filter(o=>o.id!==s.id&&['R','HW'].includes(o.type)&&o.type!==s.type&&
           footprint((proposals.get(o.id)||this.node(o)).p,(proposals.get(o.id)||this.node(o)).h,o.type).some(c=>inArea(m,c,'bay')));
         if(conflicting.length){
           // Existing Bay occupant has priority; deterministic tie-break for simultaneous arrivals.
           const already=conflicting.find(o=>footprint(o.p,o.h,o.type).some(c=>inArea(m,c,'bay')));
           const winner=already||[s,...conflicting].sort((a,b)=>a.startStep-b.startStep||a.id.localeCompare(b.id))[0];
           if(winner.id!==s.id){proposals.set(s.id,this.node(s));waits.set(s.id,'BAY_RESOURCE_OCCUPIED');blockers.set(s.id,conflicting.map(o=>o.id));changed=true;}
         }
       }
       if(enabled.includes('SR-042')){
         const edges=[];for(let i=0;i<rstate.length;i++)for(let j=i+1;j<rstate.length;j++){
           const a=rstate[i],b=rstate[j];if(t<a.startStep||t<b.startStep)continue;
           if(this.conflicts(a,proposals.get(a.id),b,proposals.get(b.id)))edges.push([a,b]);
         }
         if(edges.length){
           // Connected components, not isolated pairwise action overwrites.
           const neighbors=new Map();for(const [a,b] of edges){if(!neighbors.has(a.id))neighbors.set(a.id,new Set());if(!neighbors.has(b.id))neighbors.set(b.id,new Set());neighbors.get(a.id).add(b.id);neighbors.get(b.id).add(a.id);}
           const visited=new Set();for(const start of neighbors.keys()){if(visited.has(start))continue;
             const ids=[],queue=[start];while(queue.length){const id=queue.shift();if(visited.has(id))continue;visited.add(id);ids.push(id);for(const x of neighbors.get(id)||[])queue.push(x);}
             const group=ids.map(id=>rstate.find(s=>s.id===id));
             const moving=group.filter(s=>this.active(s,t)&&s.done<s.missions.length&&(!same(proposals.get(s.id).p,s.p)||proposals.get(s.id).h!==s.h));
             // A blocked group needs one globally feasible mover, not one mover per pair.
             const candidates=[];
             for(const s of moving){
               const blocked=group.filter(o=>o.id!==s.id);
               const route=this.replan(s,t,'AGENT_CONFLICT',blocked);
               if(route?.length>1&&blocked.every(o=>!this.conflicts(s,route[1],o,this.node(o))))
                 candidates.push({s,step:route[1],route,cost:route.length});
             }
             if(!candidates.length){
               for(const s of group.filter(x=>this.active(x,t)&&x.done<x.missions.length)){
                 const plan=retreatPlan(s,snapshot,dynamicPos(m,t+1));
                 if(plan?.path?.length>1&&group.filter(o=>o.id!==s.id).every(o=>!this.conflicts(s,plan.path[1],o,this.node(o))))
                   candidates.push({s,step:plan.path[1],route:plan.path,retreat:true,cost:plan.cost+3});
               }
             }
             candidates.sort((a,b)=>a.cost-b.cost||a.s.id.localeCompare(b.s.id));
             const chosen=candidates[0];
             for(const s of group){if(chosen?.s.id===s.id)continue;
               if(this.active(s,t)){proposals.set(s.id,this.node(s));waits.set(s.id,'YIELD SR-042');blockers.set(s.id,group.filter(z=>z.id!==s.id).map(z=>z.id));changed=true;}
             }
             if(chosen){
               if(!same(proposals.get(chosen.s.id).p,chosen.step.p)||proposals.get(chosen.s.id).h!==chosen.step.h){
                 setRoute(t,chosen.s,chosen.route,chosen.retreat?'COORDINATOR RETREAT COST '+chosen.cost:'COORDINATOR REROUTE',!!chosen.retreat);
                 proposals.set(chosen.s.id,{p:chosen.step.p.slice(),h:chosen.step.h});waits.delete(chosen.s.id);changed=true;
               }
             }else{
               for(const s of group.filter(x=>this.active(x,t))){proposals.set(s.id,this.node(s));waits.set(s.id,'JOINT_CONFLICT_UNRESOLVED');}
             }
           }
         }
       }
       if(!changed)break;
     }
     return {proposals,waits,blockers};
   }
   trackWaitGraph(t,proposals,waits,blockers){
     this.waitGraph.clear();for(const s of rstate){
       const blockersNow=blockers.get(s.id)||[];if(this.active(s,t)&&waits.has(s.id))this.waitGraph.set(s.id,blockersNow);
       if(!this.active(s,t))continue;
       if(waits.has(s.id)){s.stalled=(s.stalled||0)+1;}
       else s.stalled=0;
     }
     const cycles=[],seen=new Set();
     for(const id of this.waitGraph.keys()){
       const path=[],onPath=new Set();const explore=(cur)=>{if(onPath.has(cur)){cycles.push(path.slice(path.indexOf(cur)));return;}if(seen.has(cur))return;onPath.add(cur);path.push(cur);
         for(const next of this.waitGraph.get(cur)||[])if(this.waitGraph.has(next))explore(next);
         path.pop();onPath.delete(cur);seen.add(cur);};explore(id);
     }
     if(cycles.length&&t%25===0)report(t,'SYSTEM','WAIT_CYCLE_DETECTED',JSON.stringify(cycles),null);
     const stalled=rstate.filter(s=>this.active(s,t)&&s.stalled>=40&&s.stalled%40===0);
     for(const s of stalled)report(t,s.id,'STARVATION_CANDIDATE',waits.get(s.id)||'UNKNOWN',s.p);
   }
   step(t,snapshot,dyn,nextDyn){
     const {proposals,waits,blockers}=this.proposeActions(t,snapshot);
     this.jointValidate(t,proposals,waits,blockers,snapshot);
     this.trackWaitGraph(t,proposals,waits,blockers);
     // FINAL, non-mutating joint audit before atomic commit in simulate().
     for(const s of rstate){const action=proposals.get(s.id)||this.node(s);
       const check=this.evaluateTransition(s,this.node(s),action,t,rstate,true);
       if(!check.valid){
         const stay=this.node(s),safeStay=this.evaluateTransition(s,stay,stay,t,rstate,true).valid;
         const escape=!safeStay&&enabled.includes('SR-024')?this.safeDynamicEscape(s,t):null;
         proposals.set(s.id,escape||stay);
         waits.set(s.id,escape?'DYNAMIC_SAFE_EGRESS':safeStay?check.reasonCode:'UNSAFE_WAIT_NO_ESCAPE');
         blockers.set(s.id,check.blockingAgents);
       }
     }
     return {actions:proposals,waits,blockers};
   }
 }
 const coordinator=new CentralizedRuleCoordinator();
 function zoneCellAllowed(c,type){const z=key(c);return type==='R'?(m.layer.robotZone.has(z)||m.layer.bay.has(z)):
   type==='FL'?(!m.layer.bay.has(z)&&!m.layer.wait.has(z)&&(!m.layer.forkliftZone.size||m.layer.forkliftZone.has(z))):
   type==='HW'?(!m.layer.robotZone.has(z)||m.layer.bay.has(z)||m.layer.wait.has(z)):true;}

 for(let t=0;t<=horizonSafety;t++){
   const dyn=dynamicPos(m,t),nextDyn=dynamicPos(m,t+1),movingHazards=new Set([...dynamicBanned(dyn),...dynamicBanned(nextDyn)]);
   let changed=false;
   const frame={t,dyn:dyn.map(d=>({id:d.id,p:d.p.slice()})),agents:[],contacts:[],violations:0,cum:null,score:0};
   if(t===0){
     frame.agents=rstate.map(s=>({id:s.id,type:s.type,p:s.p.slice(),h:s.h,mi:1,done:0,total:s.missions.length,status:t<s.startStep?'NOT_STARTED':'READY',flag:'',active:t>=s.startStep,foot:footprint(s.p,s.h,s.type),route:[],goal:s.missions[0]?.goal||null,replans:0,backsteps:0,trafficHold:0,blockedSince:0,stalled:0,blockedBy:[]}));
     frame.cum={...cum};frame.score=0;frames.push(frame);continue;
   }
   let snapshot=rstate.map(s=>({...s,foot:footprint(s.p,s.h,s.type),active:t>=s.startStep&&!s.failed&&s.done<s.missions.length}));
   // V27.1: ONE coordinator produces and validates all proposals from the SAME immutable
   // start-of-step snapshot. Rules no longer overwrite each other's proposals sequentially.
   const arbitration=coordinator.step(t-1,snapshot,dynamicPos(m,t-1),dyn);
   for(const s of rstate){
     const action=arbitration.actions.get(s.id);
     s.proposal=action?{p:action.p.slice(),h:action.h}:{p:s.p.slice(),h:s.h};
     s.waitCause=arbitration.waits.get(s.id)||null;
     s.blockedBy=arbitration.blockers.get(s.id)||[];
     if(s.waitCause&&(!s.lastWaitLog||t-s.lastWaitLog>=30||s.lastWaitCause!==s.waitCause)){
       report(t,s.id,'COORDINATOR_WAIT',s.waitCause+' blockers='+s.blockedBy.join(','),s.p);
       s.lastWaitLog=t;s.lastWaitCause=s.waitCause;
     }
   }
   for(const s of rstate){
     if(t<s.startStep||s.failed||(s.done>=s.missions.length&&!enabled.includes('SR-024')))continue;
     let old=s.p.slice(),oldHeading=s.h,p=s.proposal.p,h=s.proposal.h;
     // A forklift turn at the same grid anchor counts as an executed state transition.
     const moved=!same(p,s.p),turned=h!==s.h;
     if(moved||turned){s.p=p.slice();s.h=h;changed=true;
       if(moved){s.travel+=Math.abs(p[0]-old[0])+Math.abs(p[1]-old[1]);cum.O+=Math.abs(p[0]-old[0])+Math.abs(p[1]-old[1]);}
       if(s.done>=s.missions.length)report(t,s.id,'POST_MISSION_EGRESS','Protective relocation',s.p);
       if(turned)report(t,s.id,'TURN','Heading '+oldHeading+'→'+h,s.p);
       if(s.detour&&same(s.detour.path[Math.min(s.detour.idx+1,s.detour.path.length-1)].p,s.p)&&s.detour.path[Math.min(s.detour.idx+1,s.detour.path.length-1)].h===s.h)s.detour.idx++;
       else if(!s.detour&&s.route&&same(s.route[Math.min(s.idx+1,s.route.length-1)].p,s.p)&&s.route[Math.min(s.idx+1,s.route.length-1)].h===s.h)s.idx++;
       s.status=s.done>=s.missions.length?'COMPLETE_SAFE_EGRESS':s.detour?'DETOUR':'MOVING';
     }else{
       if(s.waitCause){s.wait++;cum.W+=1;report(t,s.id,'WAIT',s.waitCause,s.p);s.status=s.waitCause;}
       else s.status='STATIONARY';
     }
     if(s.done<s.missions.length&&!s.detour&&s.route&&same(s.p,goalOf(s))){
       s.done++;changed=true;report(t,s.id,'MISSION_COMPLETE','M'+s.done,s.p);
       s.mi++;s.route=null;s.idx=0;s.detour=null;s.sr012PendingMission=null;
       if(s.done>=s.missions.length)s.status='COMPLETE';
     }
   }
   const live=rstate.map(s=>({id:s.id,type:s.type,p:s.p.slice(),h:s.h,mi:s.mi+1,done:s.done,total:s.missions.length,status:s.status,flag:s.flag,active:t>=s.startStep,foot:footprint(s.p,s.h,s.type),route:s.detour?s.detour.path.slice(s.detour.idx).map(n=>n.p):s.route?s.route.slice(s.idx).map(n=>n.p):[],goal:goalOf(s)||null,replans:s.replans,backsteps:s.backsteps}));
   const contacts=pairContacts(live.filter(s=>s.active));
   // Time-discrete edge swaps are contacts even if neither agent ends on the
   // same cell. This is especially important in one-cell corridors.
   for(let i=0;i<live.length;i++)for(let j=i+1;j<live.length;j++){
     const a=live[i],b=live[j],oldA=snapshot[i],oldB=snapshot[j];
     if(!a.active||!b.active||!oldA?.active||!oldB?.active)continue;
     if(same(a.p,oldA.p)&&a.h===oldA.h)continue;
     if(same(b.p,oldB.p)&&b.h===oldB.h)continue;
     if(!intersects(oldA.foot,b.foot)||!intersects(oldB.foot,a.foot))continue;
     if(!contacts.some(c=>[c.a,c.b].includes(a.id)&&[c.a,c.b].includes(b.id)))
       contacts.push({a:a.id,b:b.id,p:a.p.slice(),kind:'EDGE_SWAP'});
   }
   for(const actor of live.filter(s=>s.active))for(const cell of actor.foot){
     if(m.layer.staticObstacle.has(key(cell)))contacts.push({a:actor.id,b:'STATIC_HAZARD',p:cell.slice()});
     for(const d of dyn)if(same(d.p,cell))contacts.push({a:actor.id,b:d.id,p:cell.slice()});
   }
   frame.ruleHits=[];
   for(const s of live){if(!s.active)continue;
     // SR-042 checks contacts among any Agent pair, not just humanoid-forklift.
     for(const rule of selected){let violated=rule==='SR-042'?contacts.some(c=>(c.a===s.id||c.b===s.id)&&rstate.some(a=>a.id===(c.a===s.id?c.b:c.a))):
       rule==='SR-012'?(['R','HW'].includes(s.type)&&inArea(m,s.p,'bay')&&live.some(o=>o.id!==s.id&&o.type!==s.type&&['R','HW'].includes(o.type)&&inArea(m,o.p,'bay'))):
       safetyViolation(rule,m,s,dyn,contacts);
       if(violated){frame.ruleHits.push({agent:s.id,rule});cum.R+=qR;frame.violations++;if(!on||!enabled.includes(rule))report(t,s.id,'RULE_VIOLATION',rule,s.p);}
     }
   }
   for(const c of contacts){cum.C+=qC;const k=[c.a,c.b].join('|');if(!prevContacts.has(k))report(t,c.a,'CONTACT_START',c.b,c.p);}
   prevContacts=new Set(contacts.map(c=>[c.a,c.b].join('|')));
   for(const c of contacts)c.category=live.some(s=>s.id===c.b)?'Agent–Agent':'Agent–Obstacle';
   frame.agents=live;frame.contacts=contacts;frame.cum={...cum};frame.score=weights.R*cum.R+weights.C*cum.C+weights.O*cum.O+weights.W*cum.W;frames.push(frame);
   if(changed)lastProgress=t;
   if(doneOrFailed()){termination=rstate.some(s=>s.failed)?'INFEASIBLE':'COMPLETE';break;}
   if(!rstate.some(s=>t<s.startStep)&&t-lastProgress>Math.max(250,Math.min(1200,m.W*m.H/3))){termination='DEADLOCK';report(t,'SYSTEM','DEADLOCK','Unresolved: '+rstate.filter(s=>s.done<s.missions.length&&!s.failed).map(s=>s.id+' M'+(s.mi+1)+' '+s.status+' @'+key(s.p)+' blockers='+s.blockedBy.join(',')).join('; '),null);break;}
   if(t===horizonSafety){termination='ENGINE_GUARD';report(t,'SYSTEM','ENGINE_GUARD','Computation safeguard reached: '+rstate.filter(s=>s.done<s.missions.length&&!s.failed).map(s=>s.id+' M'+(s.mi+1)+' @'+key(s.p)+' blockedBy='+s.blockedBy.join(',')).join('; '),null);}
 }
 return {frames,events,final:frames.at(-1),rule:selected.join('+'),on,scenarioId:scenario.templateId,termination};
}
window.V26={normalize,astar,allowed,zoneAllowed,sweptCells,inflateCells,footprint,scenarioFromValidation,generatedScenario,simulate,semantic,validPoint,occupied,RULES,TYPES,mulberry32};

