const fs=require('fs'),vm=require('vm');
const map=process.argv[2]||'LOW_BASIC',rules=(process.argv[3]||'SR-024').split('+'),hazard=process.argv[4]||'dynamic';
const dom=new Map();
function el(id){if(!dom.has(id))dom.set(id,{id,value:id==='mode'?'experiment':id==='seed'?'1001':id==='hazSeed'?'1301':id==='hazDensity'?'low':'',textContent:'',innerHTML:'',disabled:false,style:{setProperty(){}},append(){},addEventListener(){},getContext(){return {clearRect(){},fillRect(){},beginPath(){},arc(){},fill(){},stroke(){},fillText(){},measureText(){return {width:12}},save(){},restore(){},moveTo(){},lineTo(){},strokeRect(){},setTransform(){},scale(){}}},getBoundingClientRect(){return {width:900,height:580}}});return dom.get(id)}
const window={addEventListener(){},matchMedia(){return {matches:true}},V26:null};
const document={getElementById:el,createElement(){return el('created'+dom.size)},querySelectorAll(){return []}};
const ctx=vm.createContext({window,document,console,setInterval(){return 0},clearInterval(){},setTimeout(){return 0},clearTimeout(){},Blob,URL,localStorage:{getItem(){return null},setItem(){},removeItem(){}}});
function run(f){vm.runInContext(fs.readFileSync(__dirname+'/'+f,'utf8'),ctx,{filename:f});}
run('maps.js');run('engine.js');run('ui.js');
let script=`(()=>{const m=v26.normalize(window.V26_EXAMPLES[${JSON.stringify(map)}],${JSON.stringify(map)});current=m;library=[m];$('map').value=m.id;$('template').value=m.id;$('mode').value='experiment';$('seed').value='1001';$('hazSeed').value='1301';$('hazDensity').value='low';scenario=v26.generatedScenario(m,m,{seed:1001,agents:m.agents.map(a=>({id:a.id,type:a.type,count:20,startStep:0}))});return {m,scenario}})()`;
try{
 const out=vm.runInContext(script,ctx);
 if(hazard.includes('static')) vm.runInContext("makeHazards('static')",ctx);
 if(hazard.includes('dynamic'))vm.runInContext("makeHazards('dynamic')",ctx);
 let stat=vm.runInContext("({message:$('hazStatus').textContent,dyn:current.dyn.length,sta:current.layer.staticObstacle.size})",ctx);
 if(stat.message.startsWith('GENERATION FAILED'))throw Error(stat.message);
 const options={TS:1,qR:1,qC:1,weights:{R:8,C:25,O:.12,W:.45}};
 const t=Date.now();const off=ctx.window.V26.simulate(out.m,out.scenario,rules,false,options);const on=ctx.window.V26.simulate(out.m,out.scenario,rules,true,options);
 const contacts=(v)=>v.frames.reduce((n,f)=>n+f.contacts.filter(c=>c.b.startsWith('GD')).length,0);
 const completion=v=>v.final.agents.reduce((n,a)=>n+a.done,0);
 const coverage=v=>v.frames.filter(f=>f.dyn.length>0).length/v.frames.length;
 const ruleOn=on.events.filter(e=>e.agent!=='SYSTEM' && e.agent!=='SYSTEM');
 const codes={};for(const e of on.events){const k=e.code||e.type||e.reason||e.reasonCode||'unknown';codes[k]=(codes[k]||0)+1}
 const agentContacts=v=>v.frames.reduce((n,f)=>n+f.contacts.filter(c=>!String(c.b).startsWith('GD')).length,0);
 const routeDifference=(()=>{const a=off.frames,b=on.frames,limit=Math.min(a.length,b.length);let n=0;for(let i=0;i<limit;i++){const ak=new Map(a[i].agents.map(x=>[x.id,x.p.join(',')]));for(const q of b[i].agents)if(ak.get(q.id)!==q.p.join(','))n++;}return n})();
 console.log(JSON.stringify({map,rules,hazard,ms:Date.now()-t,off:completion(off),on:completion(on),total:out.scenario.agents.reduce((n,a)=>n+a.missions.length,0),offTermination:off.termination,onTermination:on.termination,offDynContacts:contacts(off),onDynContacts:contacts(on),offAgentContacts:agentContacts(off),onAgentContacts:agentContacts(on),offCoverage:coverage(off),onCoverage:coverage(on),onEvents:on.events.length,onEventCodes:codes,routeDifference,hazardStat:stat}));
}catch(e){console.log(JSON.stringify({map,rules,hazard,error:e.stack||e.message}));process.exitCode=1}
