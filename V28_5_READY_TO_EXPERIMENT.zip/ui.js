
'use strict';
const $=id=>document.getElementById(id);const v26=window.V26;
let library=[],current=null,scenario=null,pair=null,clock=null,frame=0,loaded=false;let generatedHazards={static:[],dynamic:[]};
// E1 isolation: SR-016 and SR-018 can be toggled independently; execution semantics are unchanged.
const byName=async(name)=>{if(window.V26_EXAMPLES?.[name])return window.V26_EXAMPLES[name];const r=await fetch('maps/'+name+'.json');if(!r.ok)throw Error('Fetch map '+name+' failed');return await r.json();};
function addMap(raw,id){let m=v26.normalize(raw,id);let i=library.findIndex(z=>z.id===id);if(i>=0)library[i]=m;else library.push(m);refill();return m;}
function refill(){let old=$('map').value;for(const [id,el] of [['map',$('map')],['template',$('template')]]){let last=el.value;el.innerHTML='';for(const m of library){let o=document.createElement('option');o.value=m.id;o.textContent=(window.V28_MAP_LABELS?.[m.id]||m.id)+(window.V28_MAP_LABELS?.[m.id]?'':' · imported');el.append(o);}if(library.some(m=>m.id===last))el.value=last;}if(library.some(m=>m.id===old))$('map').value=old;else if(library.length)$('map').value=library[0].id;$('template').value=$('map').value;const temp=library.find(m=>m.agents.length);if(temp&&!library.find(m=>m.id===$('template').value)?.agents.length)$('template').value=temp.id;$('libraryCount').textContent=library.length+' maps loaded';selectMap();}
function selectMap(){pause();pair=null;$('downloadAll').disabled=true;scenario=null;frame=0;generatedHazards={static:[],dynamic:[]};$('timeline').min=0;$('timeline').value=0;$('timeline').max=1;$('timeline').style.setProperty('--timeline-progress','0%');current=library.find(m=>m.id===$('map').value);$('template').value=current?.id||'';$('mapStatus').textContent=current?`${current.W}×${current.H} · ${current.agents.length} agent(s) · ${current.issues.length} geometry warnings`:'No selected map';$('referenceLabel').style.display=$('mode').value==='validation'?'none':'';drawAll();renderRows();}
async function loadExamples(){for(const id of window.V28_MAP_IDS){try{addMap(await byName(id),id);}catch(e){$('mapStatus').textContent='Built-in map load error: '+e.message;}}loaded=true;}
$('loadExamples').onclick=loadExamples;$('map').onchange=selectMap;$('template').onchange=()=>{$('template').value=current?.id||'';scenario=null;renderRows();};$('mode').onchange=()=>{pause();pair=null;scenario=null;frame=0;$('timeline').value=0;$('referenceLabel').style.display=$('mode').value==='validation'?'none':'';renderRows();drawAll();};$('importBtn').onclick=()=>$('files').click();
$('files').onchange=async e=>{
 const selected=[...e.target.files];let imported=[],failed=[];
 for(const f of selected){
  try{
   const raw=JSON.parse(await f.text());
   let id=f.name.replace(/\.json$/i,'');
   const map=addMap(raw,id);imported.push(map);
  }catch(err){failed.push(f.name+': '+err.message);}
 }
 if(imported.length){
  const last=imported[imported.length-1];
  $('map').value=last.id;
  if(last.agents.length)$('template').value=last.id;
  selectMap();
  $('mapStatus').textContent='✓ Imported '+imported.length+' map(s). Selected: '+last.id+' ('+last.W+'×'+last.H+', '+last.agents.length+' agents).'+(last.issues.length?' '+last.issues.length+' geometry warnings.':'');
  $('runStatus').textContent='MAP IMPORT SUCCESS';
 }
 if(failed.length){
  $('mapStatus').textContent+=(imported.length?' | ':'')+'✗ Import failed: '+failed.join(' | ');
  $('runStatus').textContent='MAP IMPORT ERROR';
 }
 if(!selected.length)$('mapStatus').textContent='No files selected.';
 e.target.value='';
};
function mapTemplate(){return current;}

const PREF_KEY='warehouseSimulator.v28_3.generatorSettings';
const GENERATOR_DEFAULTS={taskSeed:1001,hazardSeed:1301,hazardDensity:'low'};
let generatorPrefs=null;
function readGeneratorPrefs(){try{const p=JSON.parse(localStorage.getItem(PREF_KEY)||'null');return p&&p.version===1&&typeof p==='object'?p:null;}catch(e){return null;}}
function saveGeneratorPrefs(){try{localStorage.setItem(PREF_KEY,JSON.stringify(generatorPrefs));}catch(e){/* file/private mode restrictions */}}
function safeInteger(v,min,max,fallback){const n=Number(v);return Number.isInteger(n)&&n>=min&&n<=max?n:fallback;}
function preferencesForMap(id){return generatorPrefs?.maps?.[id]||{};}
function captureGeneratorPrefs(){
 if(!generatorPrefs)generatorPrefs={version:1,maps:{}};
 generatorPrefs.taskSeed=safeInteger($('seed').value,0,2147483647,1001);
 generatorPrefs.hazardSeed=safeInteger($('hazSeed').value,0,2147483647,1301);
 generatorPrefs.hazardDensity=['low','medium','high'].includes($('hazDensity').value)?$('hazDensity').value:'low';
 if(current){const rows={};for(const a of configRows())rows[a.id]={count:safeInteger(a.count,1,100,6),startStep:safeInteger(a.startStep,0,100000,0)};generatorPrefs.maps[current.id]=rows;}
 saveGeneratorPrefs();
}
function applyGeneratorPrefs(){
 const p=generatorPrefs||{};
 $('seed').value=safeInteger(p.taskSeed,0,2147483647,1001);
 $('hazSeed').value=safeInteger(p.hazardSeed,0,2147483647,1301);
 $('hazDensity').value=['low','medium','high'].includes(p.hazardDensity)?p.hazardDensity:'low';
}
generatorPrefs=readGeneratorPrefs()||{version:1,maps:{}};
applyGeneratorPrefs();
$('seed').addEventListener('input',captureGeneratorPrefs);
$('hazSeed').addEventListener('input',captureGeneratorPrefs);
$('hazDensity').addEventListener('change',captureGeneratorPrefs);
$('taskRows').addEventListener('input',e=>{if(e.target.matches('input[data-count],input[data-start]'))captureGeneratorPrefs();});
$('resetGeneratorDefaults').onclick=()=>{
 generatorPrefs={version:1,maps:{}};
 try{localStorage.removeItem(PREF_KEY);}catch(e){}
 applyGeneratorPrefs();
 renderRows();
 $('taskStatus').textContent='Generator preferences restored to V28.2 defaults. Frozen scenario unchanged.';
};
function renderRows(){
 const tpl=mapTemplate();
 // Agent identities/counts/initial positions come from the experiment map; templates supply workflows only.
 const arr=current?.agents?.length?current.agents:(($('mode').value==='experiment')?(tpl?.agents||[]):[]);
 const saved=preferencesForMap(current?.id),tbody=$('taskRows');tbody.innerHTML='';
 for(const a of arr){let ref=tpl?.agents.find(x=>x.id===a.id)||tpl?.agents.find(x=>x.type===a.type);let row=document.createElement('tr');
  row.innerHTML=`<td>${a.id}</td><td>${a.type}</td><td>(${(a.initial||[]).join(',')})</td><td><input type="number" min="1" max="100" value="${safeInteger(saved[a.id]?.count,1,100,Math.max(1,a.missions.length||ref?.missions.length||6))}" data-count="${a.id}"></td><td><input type="number" min="0" value="${safeInteger(saved[a.id]?.startStep,0,100000,a.startStep||0)}" data-start="${a.id}"></td>`;tbody.append(row);
 }
 $('taskStatus').textContent='Experiment map: '+(current?.id||'none')+' · Workflow source: '+(tpl?.id||'none')+'. '+arr.length+' agent(s).';
}
function configRows(){return [...$('taskRows').querySelectorAll('input[data-count]')].map(inp=>{let id=inp.dataset.count;let a=current.agents.find(a=>a.id===id)||mapTemplate()?.agents.find(a=>a.id===id);return{id,type:a.type,count:Number(inp.value),startStep:Number($('taskRows').querySelector(`[data-start="${id}"]`).value)};});}
$('taskBtn').onclick=()=>{$('taskWindow').classList.add('open');renderRows();};$('closeTask').onclick=()=>$('taskWindow').classList.remove('open');$('resetTemplate').onclick=()=>{scenario=null;renderRows();};
function generate(){if(!current)throw Error('Import a map first');if($('mode').value==='experiment'&&(generatedHazards.static.length||generatedHazards.dynamic.length)){if(!scenario)throw Error('CLEAR_GENERATED_HAZARDS_BEFORE_REGENERATING_MISSIONS');const requested=configRows();if(requested.some(r=>{const a=scenario.agents.find(a=>a.id===r.id);return !a||a.missions.length!==r.count||a.startStep!==r.startStep;})||Number($('seed').value)!==Number(scenario.seed))throw Error('CLEAR_GENERATED_HAZARDS_BEFORE_CHANGING_MISSIONS');return scenario;}let template=mapTemplate();let starts=Object.fromEntries(configRows().map(x=>[x.id,x.startStep]));scenario=$('mode').value==='validation'?v26.scenarioFromValidation(current,starts):v26.generatedScenario(current,template,{seed:Number($('seed').value),agents:configRows()});$('taskStatus').textContent=scenario.agents.length+' agents · '+scenario.agents.reduce((s,a)=>s+a.missions.length,0)+' missions · '+scenario.warnings.join(' | ');$('missionPreview').innerHTML='<pre style="font-size:11px">'+scenario.agents.map(a=>a.id+' [start '+a.startStep+'] '+a.missions.map((z,i)=>'M'+(i+1)+' '+z.start+'→'+z.goal).join(' | ')).join('\n')+'</pre>';return scenario;}
$('generate').onclick=()=>{try{generate();}catch(e){$('taskStatus').textContent=e.message;}};$('freeze').onclick=()=>{try{generate();$('taskWindow').classList.remove('open');$('runStatus').textContent='SCENARIO FROZEN';}catch(e){$('taskStatus').textContent=e.message;}};
function options(){return{TS:Math.max(.01,Number($('TS').value)),qR:Number($('qR').value),qC:Number($('qC').value),weights:{R:Number($('wR').value),C:Number($('wC').value),O:Number($('wO').value),W:Number($('wW').value)}};}
function chosenRules(){return [...document.querySelectorAll('.rulecheck:checked')].map(e=>e.value);}
function run(){
 if(!current)throw Error('Select map');if(!scenario)generate();
 let opts=options(),rules=chosenRules();if(!rules.length)throw Error('Select at least one safety rule');
 // One immutable scenario for BOTH arms; rule ON/OFF must never alter start/goal pairs.
 const frozenJSON=JSON.stringify(scenario.agents.map(a=>({id:a.id,start:a.initial,missions:a.missions.map(m=>[m.start,m.goal])})));
 const off=v26.simulate(current,scenario,rules,false,opts),on=v26.simulate(current,scenario,rules,true,opts);
 if(JSON.stringify(scenario.agents.map(a=>({id:a.id,start:a.initial,missions:a.missions.map(m=>[m.start,m.goal])})))!==frozenJSON)throw Error('CONTROLLED_VARIABLES_MUTATED');
 pair={off,on,rule:rules.join('+'),opts};$('downloadAll').disabled=false;frame=0;pause();
 const end=Math.max(off.frames.length,on.frames.length)-1;
 $('timeline').min=0;$('timeline').max=end;$('timeline').value=0;
 drawAll();$('runStatus').textContent='STEP 0 READY · OFF '+off.termination+' · ON '+on.termination;
}
$('run').onclick=()=>{pause();try{run();}catch(e){$('runStatus').textContent='ERROR: '+e.message;console.error(e);}};function pause(){if(clock){clearInterval(clock);clock=null;}$('play').textContent='▶ Play';}function tick(){let lim=Number($('timeline').max)||0;if(frame>=lim){pause();return;}frame++;$('timeline').value=frame;drawAll();}
$('play').onclick=()=>{if(clock){pause();return;}if(!pair){$('run').click();if(!pair)return;}if(frame>=Number($('timeline').max)){frame=0;$('timeline').value=0;drawAll();}$('play').textContent='⏸ Pause';clock=setInterval(tick,Math.max(25,170/Number($('speed').value)));};$('reset').onclick=()=>{pause();frame=0;$('timeline').value=0;drawAll();};$('step').onclick=()=>{pause();tick();};$('back').onclick=()=>{pause();frame=Math.max(0,frame-1);$('timeline').value=frame;drawAll();};$('timeline').oninput=()=>{pause();frame=Number($('timeline').value);drawAll();};$('speed').onchange=()=>{if(clock){pause();$('play').click();}};
const color={R:'#35f5e3',FL:'#f9dc55',HW:'#ff91cd'};
function drawMap(el,trace){const c=el.getContext('2d');if(!current){c.clearRect(0,0,el.width,el.height);return;}let m=current,S=Math.min(el.width/m.W,el.height/m.H);c.clearRect(0,0,el.width,el.height);c.fillStyle='#25394a';c.fillRect(0,0,m.W*S,m.H*S);let layer=m.layer;function cells(k,fill){c.fillStyle=fill;for(let xy of layer[k]){let [x,y]=xy.split(',').map(Number);c.fillRect(x*S,y*S,S,S);}}cells('forkliftZone','#34465d');cells('robotZone','#55434e');cells('robotOnly','#384f57');cells('crossing','#6b6044');cells('bay','#805d88');cells('wait','#297c7b');cells('rack','#c2a57a');cells('wall','#8899a9');cells('parking1','#171d23');cells('parking2','#171d23');cells('staticObstacle','#ff7c49');if(S>8){c.strokeStyle='#ffffff1a';c.lineWidth=.3;for(let x=0;x<=m.W;x++){c.beginPath();c.moveTo(x*S,0);c.lineTo(x*S,m.H*S);c.stroke();}for(let y=0;y<=m.H;y++){c.beginPath();c.moveTo(0,y*S);c.lineTo(m.W*S,y*S);c.stroke();}}if(S>=6){c.font=`${Math.max(9,S)}px sans-serif`;for(let xy of layer.staticObstacle){let [x,y]=xy.split(',').map(Number);c.fillText('⚠',x*S-.5,(y+1)*S);}}let f=trace?.frames[Math.min(frame,trace.frames.length-1)];if(!f)return;
for(const d of f.dyn){c.fillStyle='#ff4848';c.fillRect(d.p[0]*S,d.p[1]*S,S,S);if(S>6){c.font=`${Math.max(9,S*1.1)}px sans-serif`;c.fillText('🚧',d.p[0]*S-2,d.p[1]*S+S);}}
for(const a of f.agents){if(!a.active)continue;const col=color[a.type];if(a.route.length){c.beginPath();a.route.forEach((p,i)=>i===0?c.moveTo((p[0]+.5)*S,(p[1]+.5)*S):c.lineTo((p[0]+.5)*S,(p[1]+.5)*S));c.strokeStyle=col+'b9';c.lineWidth=3;c.stroke();}if(a.goal){
  const cx=(a.goal[0]+.5)*S,cy=(a.goal[1]+.5)*S;
  const reduceMotion=window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  const pulse=reduceMotion?1:(.72+.28*Math.sin(performance.now()/240));
  const outer=Math.max(5,S*.8),inner=outer*.43;
  c.save();c.globalAlpha=pulse;c.shadowColor='#fff1a4';c.shadowBlur=reduceMotion?0:Math.max(6,S*.6);
  c.beginPath();for(let k=0;k<10;k++){const r=k%2?inner:outer,ang=-Math.PI/2+k*Math.PI/5;const xx=cx+r*Math.cos(ang),yy=cy+r*Math.sin(ang);if(k===0)c.moveTo(xx,yy);else c.lineTo(xx,yy);}c.closePath();c.fillStyle='#fff5aa';c.fill();c.strokeStyle=col;c.lineWidth=1.5;c.stroke();c.restore();
 }c.fillStyle=col;for(const p of a.foot)c.fillRect(p[0]*S+.6,p[1]*S+.6,S-1.2,S-1.2);c.strokeStyle='#fff';c.lineWidth=.8;c.strokeRect(a.p[0]*S+.6,a.p[1]*S+.6,S-1.2,S-1.2);if(S>=7){c.fillStyle='#fff';c.font='bold 10px Arial';c.fillText(a.id,a.p[0]*S,a.p[1]*S-2);}if(a.flag){c.fillStyle='#ffe783';c.font='bold 9px Arial';c.fillText(a.flag,a.p[0]*S,a.p[1]*S-13);}}
for(const x of f.contacts){c.strokeStyle='#ff4242';c.lineWidth=3;c.strokeRect(x.p[0]*S-2,x.p[1]*S-2,S+4,S+4);} }
function metrics(trace){if(!trace)return{score:0,viol:0,contact:0,done:0,total:0};let f=trace.frames[Math.min(frame,trace.frames.length-1)];return{score:f.score,viol:trace.frames.slice(0,Math.min(frame,trace.frames.length-1)+1).reduce((a,x)=>a+x.violations,0),contact:trace.frames.slice(0,Math.min(frame,trace.frames.length-1)+1).reduce((a,x)=>a+x.contacts.length,0),done:f.agents.reduce((a,x)=>a+x.done,0),total:f.agents.reduce((a,x)=>a+x.total,0)};}
function episodeStats(trace,until){
 if(!trace)return {agentEpisodes:0,obstacleEpisodes:0,violations:0,exposure:0,agentExposure:0,obstacleExposure:0};
 const prior={agent:new Set(),obstacle:new Set(),rule:new Set()};
 let res={agentEpisodes:0,obstacleEpisodes:0,violations:0,exposure:0,agentExposure:0,obstacleExposure:0};
 for(let i=0;i<=Math.min(until,trace.frames.length-1);i++){
   const f=trace.frames[i],current={agent:new Set(),obstacle:new Set(),rule:new Set()};
   for(const c of f.contacts){let k=[c.a,c.b].sort().join('|');let typ=c.category==='Agent–Agent'?'agent':'obstacle';current[typ].add(k);res[typ+'Exposure']++;if(!prior[typ].has(k))res[typ+'Episodes']++;}
   for(const v of f.ruleHits||[])current.rule.add(v.agent+'|'+v.rule);
   for(const v of current.rule)if(!prior.rule.has(v))res.violations++;
   res.exposure+=f.violations;
   Object.assign(prior,current);
 }
 return res;
}
function metricHTML(m){return [['Rule exposure',m.viol],['Contact pair-steps',m.contact],['Missions',m.done+'/'+m.total],['Penalty · P_loss',m.score.toFixed(1)]].map(([n,v])=>`<div class="metric"><span class="tiny">${n}</span><b>${v}</b></div>`).join('');}
function chartCanvas(canvas){
 const rect=canvas.getBoundingClientRect();
 const w=Math.max(300,rect.width||700),h=Math.max(150,rect.height||220),dpr=Math.max(1,window.devicePixelRatio||1);
 const pxW=Math.round(w*dpr),pxH=Math.round(h*dpr);
 if(canvas.width!==pxW||canvas.height!==pxH){canvas.width=pxW;canvas.height=pxH;}
 const ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);return {w,h};
}
function drawLine(){
 const canvas=$('line'),dims=chartCanvas(canvas),c=canvas.getContext('2d'),w=dims.w,h=dims.h;
 c.clearRect(0,0,w,h);if(!pair)return;
 const maxStep=Math.max(1,Number($('timeline').max));
 const traces=[{z:pair.off,label:'WITHOUT RULE',color:'#ff9090'},{z:pair.on,label:'WITH RULE',color:'#4df5da'}];
 const maxValue=Math.max(1,...traces.map(({z})=>z.frames[Math.min(frame,z.frames.length-1)].score));
 const maxY=maxValue*1.13;
 const left=58,right=125,top=22,bottom=37,plotW=Math.max(100,w-left-right),plotH=Math.max(70,h-top-bottom);
 const X=i=>left+plotW*i/maxStep,Y=v=>top+plotH*(1-v/maxY);
 c.strokeStyle='#456076';c.fillStyle='#b8cada';c.font='11px Arial';
 for(let n=0;n<=4;n++){let value=maxY*n/4,y=Y(value);c.beginPath();c.moveTo(left,y);c.lineTo(w-18,y);c.stroke();c.fillText(value.toFixed(value>=100?0:1),4,y+4);}
 c.fillText('0',left-4,h-13);c.fillText('Step '+Math.min(frame,maxStep),Math.max(left,w-85),h-13);
 const labels=[];
 for(const {z,label,color} of traces){
   const end=Math.min(frame,z.frames.length-1);
   if(end<0||!z.frames[end])continue;
   c.strokeStyle=color;c.lineWidth=2.7;c.beginPath();
   const pointAt=i=>({x:X(z.frames[i].t),y:Y(z.frames[i].score)});
   const sampleStep=Math.max(1,Math.floor((end+1)/Math.max(300,plotW*2)));
   for(let i=0;i<=end;i+=sampleStep){let p=pointAt(i);i?c.lineTo(p.x,p.y):c.moveTo(p.x,p.y);}
   const p=pointAt(end);c.lineTo(p.x,p.y);c.stroke();
   c.fillStyle=color;c.beginPath();c.arc(p.x,p.y,4.3,0,Math.PI*2);c.fill();
   labels.push({x:p.x,y:p.y,label,value:z.frames[end].score,color});
 }
 // Anchor labels to the *visible* endpoint, not the plot's far-right margin.
 // Position them in screen coordinates, then adjust for canvas boundaries and overlap.
 const margin=5,pad=12,lineHeight=13;
 c.save();c.font='bold 10.5px Arial';
 for(const e of labels){
   e.width=Math.max(c.measureText(e.label).width,c.measureText(e.value.toFixed(1)).width);
   e.x=e.x+pad;
   if(e.x+e.width>w-margin)e.x=e.x-2*pad-e.width;
   e.x=Math.max(margin,Math.min(e.x,w-margin-e.width));
   e.y=Math.max(13,e.y-10);
   if(e.y+lineHeight>h-bottom+18)e.y=e.y-15;
 }
 if(labels.length===2){
   const a=labels[0],b=labels[1];
   const overlaps=()=>a.x<b.x+b.width+5&&b.x<a.x+a.width+5&&a.y<b.y+lineHeight+5&&b.y<a.y+lineHeight+5;
   if(overlaps()){
     // Move the second label just below the first, maintaining its endpoint-side placement.
     b.y=a.y+2*lineHeight+4;
     if(b.y+lineHeight>h-5){b.y=Math.max(13,a.y-2*lineHeight-4);}
     // If labels cannot be stacked vertically, put them on opposite sides of their markers.
     if(overlaps()){
       b.x=Math.max(margin,Math.min(b.x-b.width-2*pad,w-margin-b.width));
     }
   }
 }
 c.textAlign='left';
 for(const e of labels){
   c.font='bold 10.5px Arial';c.fillStyle=e.color;
   c.fillText(e.label,e.x,e.y);
   c.font='10px Arial';c.fillText(e.value.toFixed(1),e.x,e.y+lineHeight);
 }
 c.restore();
}
function drawBars(){
 const canvas=$('bars'),dims=chartCanvas(canvas),c=canvas.getContext('2d'),w=dims.w,h=dims.h;
 c.clearRect(0,0,w,h);if(!pair)return;
 const vals=[pair.off,pair.on].map(tr=>{const f=tr.frames[Math.min(frame,tr.frames.length-1)],cum=f.cum,weights=pair.opts.weights;return {items:[['R',cum.R*weights.R],['C',cum.C*weights.C],['O',cum.O*weights.O],['W',cum.W*weights.W]],total:f.score};});
 const max=Math.max(1,...vals.map(a=>a.total))*1.25,colors={R:'#ffbd7d',C:'#ff777b',O:'#7fb4f5',W:'#c68aff'};
 const plotTop=36,plotBottom=h-38,scale=(plotBottom-plotTop)/max;
 for(let k=0;k<2;k++){const x=k?w*.73:w*.27;let bottom=plotBottom;
   for(const [key,value] of vals[k].items){const height=Math.max(0,value*scale);c.fillStyle=colors[key];c.fillRect(x-49,bottom-height,98,height);bottom-=height;}
   c.fillStyle='#eaf6fb';c.textAlign='center';c.font='bold 12px Arial';c.fillText(vals[k].total.toFixed(1),x,Math.max(plotTop+14,bottom-8));
   c.font='bold 11px Arial';c.fillText(k?'WITH RULE':'WITHOUT RULE',x,h-12);
 }
 c.textAlign='left';let x=8;
 for(const a of [['R','Rule'],['C','Collision'],['O','Step'],['W','Waiting']]){
   c.fillStyle=colors[a[0]];c.fillRect(x,5,10,10);c.fillStyle='#dce9f3';c.font='10px Arial';c.fillText(a[1],x+13,14);x+=a[0]==='C'?113:92;
 }
}
function updateTimelineProgress(){
 const slider=$('timeline');const lo=Number(slider.min)||0,hi=Number(slider.max)||0;
 const pct=hi>lo?Math.max(0,Math.min(100,(Number(slider.value)-lo)/(hi-lo)*100)):0;
 slider.style.setProperty('--timeline-progress',pct.toFixed(5)+'%');
}
function drawAll(){updateTimelineProgress();drawMap($('offMap'),pair?.off);drawMap($('onMap'),pair?.on);$('stepLabel').textContent='Step '+frame+' / '+(pair?Math.max(pair.off.frames.length,pair.on.frames.length)-1:0);if(!pair){$('offStats').innerHTML='Rule violations <b>0</b> · Agent–Agent <b>0</b> · Agent–Obstacle <b>0</b>'; $('onStats').innerHTML=$('offStats').innerHTML;return;}let a=metrics(pair.off),b=metrics(pair.on);$('offScore').textContent=a.score.toFixed(1);$('onScore').textContent=b.score.toFixed(1);$('offMetrics').innerHTML=metricHTML(a);$('onMetrics').innerHTML=metricHTML(b);
 for(const [id,tr] of [['offStats',pair.off],['onStats',pair.on]]){
   const stat=episodeStats(tr,frame);
   $(id).innerHTML='Rule violations <b>'+stat.violations+'</b> · Exposure '+stat.exposure+' &nbsp; | &nbsp; Agent–Agent collisions <b>'+stat.agentEpisodes+'</b> ('+stat.agentExposure+' pair-steps) &nbsp; | &nbsp; Agent–Obstacle collisions <b>'+stat.obstacleEpisodes+'</b> ('+stat.obstacleExposure+' pair-steps)';
 }drawLine();drawBars();$('agentsTable').innerHTML='<table><tr><th>Agent</th><th>OFF mission</th><th>ON mission</th><th>ON status</th></tr>'+pair.off.frames[Math.min(frame,pair.off.frames.length-1)].agents.map((p,i)=>{let q=pair.on.frames[Math.min(frame,pair.on.frames.length-1)].agents[i];return`<tr><td>${p.id} (${p.type})</td><td>${p.done}/${p.total}</td><td>${q.done}/${q.total}</td><td>${q.status}</td></tr>`;}).join('')+'</table>';$('events').innerHTML=pair.on.events.filter(e=>e.t<=frame).slice(-12).reverse().map(e=>`<div class="tiny"><b>${e.t}</b> · ${e.id}: ${e.type} ${e.description}</div>`).join('')||'<span class="tiny">No ON intervention yet</span>';}
let goalPulseHandle=null;
if(!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches){
 goalPulseHandle=setInterval(()=>{if(!pair||!current)return;drawMap($('offMap'),pair.off);drawMap($('onMap'),pair.on);},180);
}
window.addEventListener('resize',()=>{if(pair){drawLine();drawBars();}});
function csvDownload(filename,rows){let txt='\ufeff'+rows.map(r=>r.map(x=>'"'+String(x??'').replace(/"/g,'""')+'"').join(',')).join('\r\n');let u=URL.createObjectURL(new Blob([txt],{type:'text/csv;charset=utf-8'})),a=document.createElement('a');a.href=u;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);}
function jsonDownload(filename,data){let u=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'})),a=document.createElement('a');a.href=u;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);}
function exportData(type,sink=null){if(!pair){$('reportStatus').textContent='Run a scenario first.';return;}const mode=$('mode').value,metadata=[current.id,mode,pair.rule,scenario.seed||0],traces=[['OFF',pair.off],['ON',pair.on]];let rows=[];if(type==='config'){(sink?((filename,data)=>sink(filename,JSON.stringify(data,null,2))):jsonDownload)('scenario_config.json',{map:current.id,mode,rule:pair.rule,template:scenario.templateId,options:pair.opts,seed:scenario.seed,dynamicObstacles:current.dyn.map(d=>({id:d.id,start:d.start,path:d.path,duration:d.duration,stepInterval:d.stepInterval,repeatPeriod:d.repeatPeriod??null})),staticObstacleCells:[...current.layer.staticObstacle].map(k=>k.split(',').map(Number)),termination:{OFF:pair.off.termination,ON:pair.on.termination}});return;}if(type==='missions'){(sink?((filename,data)=>sink(filename,JSON.stringify(data,null,2))):jsonDownload)('generated_missions.json',{map:current.id,sourceTemplate:scenario.templateId,agents:scenario.agents.map(a=>({id:a.id,type:a.type,initial:a.initial,startStep:a.startStep,missions:a.missions.map(z=>({start:z.start,goal:z.goal}))}))});return;}
if(type==='score_history'){rows=[['map','mode','rule','seed','condition','step','penalty_total','rule_raw','contact_raw','operating_raw','waiting_raw','rule_weighted','contact_weighted','operating_weighted','waiting_weighted']];for(const [lab,tr] of traces)for(const f of tr.frames)rows.push([...metadata,lab,f.t,f.score,f.cum.R,f.cum.C,f.cum.O,f.cum.W,f.cum.R*pair.opts.weights.R,f.cum.C*pair.opts.weights.C,f.cum.O*pair.opts.weights.O,f.cum.W*pair.opts.weights.W]);}
if(type==='trajectory'){rows=[['map','mode','rule','seed','condition','step','agent','type','x','y','heading','mission','completed','status','replans']];for(const [lab,tr] of traces)for(const f of tr.frames)for(const a of f.agents)rows.push([...metadata,lab,f.t,a.id,a.type,...a.p,a.h,a.mi,a.done,a.status,a.replans]);}
if(type==='rule_events'){rows=[['map','mode','rule','seed','condition','step','actor','event','description','x','y']];for(const [lab,tr] of traces)for(const e of tr.events)rows.push([...metadata,lab,e.t,e.id,e.type,e.description,...(e.pos||['',''])]);}
if(type==='contacts'){rows=[['map','mode','rule','seed','condition','step','actor_a','actor_b','category','x','y']];for(const [lab,tr] of traces)for(const f of tr.frames)for(const c of f.contacts)rows.push([...metadata,lab,f.t,c.a,c.b,c.category,...c.p]);}
if(type==='mission_results'){rows=[['map','mode','rule','seed','condition','agent','mission','start_x','start_y','goal_x','goal_y','completed','completion_step']];for(const [lab,tr] of traces)for(const a of scenario.agents)for(const [i,m] of a.missions.entries()){let e=tr.events.find(e=>e.id===a.id&&e.type==='MISSION_COMPLETE'&&e.description==='M'+(i+1));rows.push([...metadata,lab,a.id,i+1,...m.start,...m.goal,Number(!!e),e?.t??'']);}}
if(type==='summary'){
 rows=[['map','mode','rule','seed','condition','penalty_total','rule_exposure','agent_agent_episodes','agent_agent_pair_steps','agent_obstacle_episodes','agent_obstacle_pair_steps','movement_steps','safety_wait_steps','completed_missions','assigned_missions','termination_status']];
 for(const [lab,tr] of traces){
   const last=tr.final,stat=episodeStats(tr,tr.frames.length-1);
   rows.push([...metadata,lab,last.score,stat.exposure,stat.agentEpisodes,stat.agentExposure,stat.obstacleEpisodes,stat.obstacleExposure,last.cum.O,last.cum.W,last.agents.reduce((s,a)=>s+a.done,0),last.agents.reduce((s,a)=>s+a.total,0),tr.termination]);
 }
}

if(sink){sink(type+'.csv','\ufeff'+rows.map(r=>r.map(x=>'"'+String(x??'').replace(/"/g,'""')+'"').join(',')).join('\r\n'));}else{csvDownload(type+'.csv',rows);$('reportStatus').textContent=type+'.csv exported.';}}
for(const b of document.querySelectorAll('[data-export]'))b.onclick=()=>exportData(b.dataset.export);
const REPORT_TYPES=['trajectory','rule_events','contacts','score_history','mission_results','summary','config','missions'];
$('downloadAll').onclick=async()=>{
 if(!pair||!scenario){$('zipStatus').textContent='Run the paired experiment first.';return;}
 const btn=$('downloadAll');btn.disabled=true;$('zipStatus').textContent='Packaging eight reports...';
 try{
  const frozen=pair, zip=new JSZip(),names=[];
  for(const type of REPORT_TYPES){exportData(type,(filename,content)=>{zip.file(filename,content);names.push(filename);});}
  if(names.length!==8||new Set(names).size!==8||pair!==frozen)throw Error('REPORT_SNAPSHOT_INVALID');
  const zipBlob=await zip.generateAsync({type:'blob',compression:'DEFLATE',compressionOptions:{level:5}});
  if(pair!==frozen)throw Error('REPORT_SNAPSHOT_CHANGED');
  const sanitize=v=>String(v).replace(/[^A-Za-z0-9_-]+/g,'-').slice(0,90);
  const filename=`V28_3_${sanitize(current.id)}_${sanitize($('mode').value)}_${sanitize(pair.rule)}_seed${sanitize(scenario.seed||0)}.zip`;
  const u=URL.createObjectURL(zipBlob),a=document.createElement('a');a.href=u;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(u),30000);
  $('zipStatus').textContent='8 reports packaged in '+filename;
 }catch(e){console.error(e);$('zipStatus').textContent='ZIP FAILED: '+e.message;}finally{btn.disabled=!pair;}
};
window.addEventListener('resize',drawAll);
loadExamples();

$('removeMap').onclick=()=>{if(!current)return;let id=current.id;if(!confirm('Delete map "'+id+'" from this browser session?'))return;pause();library=library.filter(x=>x.id!==id);current=null;pair=null;scenario=null;frame=0;refill();$('mapStatus').textContent='Deleted '+id+' from library. It remains unchanged on disk.';};
function resetHazRun(keepScenario=false){pause();pair=null;$('downloadAll').disabled=true;if(!keepScenario)scenario=null;frame=0;$('timeline').value=0;$('timeline').max=1;drawAll();}
function eligibleRobotCells(){if(!current)return[];return [...current.layer.robotZone].filter(k=>!current.obstacles.has(k)&&!current.layer.bay.has(k)&&!current.layer.wait.has(k)&&!current.layer.parking1.has(k)&&!current.layer.parking2.has(k)&&!current.agents.some(a=>a.initial&&a.initial.join(',')===k)).map(k=>k.split(',').map(Number));}
// V28.2 hazard construction: deterministic, fail-closed and before the common OFF/ON snapshot.
// Existing A*, sweptCells(), footprint(), inflateCells() and dynamicPos() remain unchanged.
function hazardError(code,detail){throw Error(code+(detail?' · '+detail:''));}
function v282Missions(){
 if($('mode').value!=='experiment')hazardError('EXPERIMENT_MODE_REQUIRED','Random hazard feasibility applies only to Experiment Mode');
 if(!scenario)generate();
 return scenario;
}
function v282EndpointFootprints(sc){
 const out=[];
 for(const a of sc.agents){
  const first=a.missions[0]?.path?.[0]?.h??1;
  out.push({agent:a.id,mission:0,kind:'INITIAL',cells:v26.footprint(a.initial,first,a.type)});
  for(let i=0;i<a.missions.length;i++){
   const leg=a.missions[i],last=leg.path?.at(-1)?.h??(a.type==='FL'?1:0);
   out.push({agent:a.id,mission:i+1,kind:'GOAL',cells:v26.footprint(leg.goal,last,a.type)});
  }
 }
 return out;
}
function v282RouteFeasible(sc, buffer, priorRoutes){
 // Do not re-run A* when a previously proved legal route does not touch the newly inflated cells.
 // Validate the swept footprint, not just forklift anchor positions.
 const updated=new Map();let checked=0;
 for(const a of sc.agents){
  let heading=1;
  for(let i=0;i<a.missions.length;i++){
   const leg=a.missions[i],id=a.id+':'+i;
   const old=priorRoutes.get(id)||leg.path;
   const clear=old&&old.length&&old[0].h===heading&&old.every((node,k)=>{
    if(!v26.allowed(current,node.p,node.h,a.type,true)||v26.footprint(node.p,node.h,a.type).some(p=>buffer.has(p.join(','))))return false;
    if(k&&v26.sweptCells(old[k-1].p,old[k-1].h,node.p,node.h,a.type).some(p=>buffer.has(p.join(','))))return false;
    return true;
   });
   let path=clear?old:null;
   if(!path){
    checked++;
    path=v26.astar(current,leg.start,leg.goal,a.type,{startHeading:heading,banned:buffer,zone:true,...(a.type==='FL'&&leg.path?.length?{goalHeading:leg.path.at(-1).h}:{})});
    if(!path)return {ok:false,code:'STATIC_MISSION_ROUTE_INFEASIBLE',detail:a.id+' M'+(i+1)};
   }
   updated.set(id,path);heading=path.at(-1).h;
  }
 }
 return {ok:true,routes:updated,checked};
}
function v282StaticCheck(sc,proposed,routeCache,endpointRecords){
 const buffer=v26.inflateCells(current,proposed,1);
 for(const item of endpointRecords){
  if(item.cells.some(p=>buffer.has(p.join(','))))return {ok:false,code:'STATIC_ENDPOINT_BUFFER_CONFLICT',detail:item.agent+' M'+item.mission+' '+item.kind};
 }
 const reachable=v282RouteFeasible(sc,buffer,routeCache);
 if(!reachable.ok)return reachable;
 return {ok:true,routes:reachable.routes,buffer,checked:reachable.checked};
}
function v282DynamicAt(d,t){
 if(t<d.start)return null;
 const phase=d.repeatPeriod>0?(t-d.start)%d.repeatPeriod:t-d.start;
 if(d.duration!=null&&phase>=d.duration)return null;
 const n=Math.floor(phase/Math.max(1,d.stepInterval||2));
 // Generated transients have lifetime short enough to never enter the reverse phase.
 const period=Math.max(1,2*(d.path.length-1));const z=n%period;
 return d.path[z<d.path.length?z:period-z];
}
function v282DynamicConflict(candidate,previous){
 // Exact time-indexed checks, including recurring imported hazards.
 for(let t=candidate.start;t<candidate.start+Math.max(candidate.duration,candidate.repeatPeriod||0);t++){
  const p=v282DynamicAt(candidate,t);if(!p)continue;
  for(const d of previous){const q=v282DynamicAt(d,t);if(q&&p[0]===q[0]&&p[1]===q[1])return {id:d.id,step:t,p};}
 }
 return null;
}
function makeHazards(type){
 if(!current){$('hazStatus').textContent='Import a map first.';return;}
 try{
  const sc=v282Missions();
  const density={low:.005,medium:.01,high:.02}[$('hazDensity').value];
  const rng=v26.mulberry32(Number($('hazSeed').value)||1301);
  const pool=eligibleRobotCells().filter(p=>!current.layer.staticObstacle.has(p.join(','))&&!current.layer.dynamic.has(p.join(',')));
  if(!pool.length)hazardError('NO_LEGAL_HAZARD_CANDIDATES');
  const count=Math.max(1,Math.round(pool.length*density));
  for(let i=pool.length-1;i>0;i--){let j=Math.floor(rng()*(i+1));[pool[i],pool[j]]=[pool[j],pool[i]];}
  const created=[],rejections={};const reject=c=>{rejections[c]=(rejections[c]||0)+1;};
  if(type==='static'){
   const endpoints=v282EndpointFootprints(sc),base=new Set(current.layer.staticObstacle);
   let routeCache=new Map();for(const a of sc.agents)for(let i=0;i<a.missions.length;i++)routeCache.set(a.id+':'+i,a.missions[i].path);
   // Existing imported obstacles also count for constraints; validate before adding new ones.
   const baseCheck=v282StaticCheck(sc,base,routeCache,endpoints);
   if(!baseCheck.ok)hazardError(baseCheck.code,'Existing map hazard makes '+baseCheck.detail+' invalid');
   routeCache=baseCheck.routes;
   const proposed=new Set(base);
   for(const p of pool){
    if(created.length>=count)break;
    const k=p.join(',');if(proposed.has(k))continue;
    proposed.add(k);
    if(current.dyn.some(d=>d.path.some(q=>q.join(',')===k))){proposed.delete(k);reject('COMBINED_HAZARD_CONFLICT');continue;}
    const checked=v282StaticCheck(sc,proposed,routeCache,endpoints);
    if(!checked.ok){proposed.delete(k);reject(checked.code);continue;}
    routeCache=checked.routes;created.push(p);
   }
   if(created.length!==count)hazardError('STATIC_HAZARD_PLACEMENT_INFEASIBLE',`requested=${count}, accepted=${created.length}, rejected=${JSON.stringify(rejections)}; no map changes committed`);
   // Atomic commit occurs only after all candidates pass; frozen missions are preserved.
   for(const p of created){const k=p.join(',');current.layer.staticObstacle.add(k);current.obstacles.add(k);}
   generatedHazards.static.push(...created);
  }else if(type==='dynamic'){
   const prior=current.dyn.slice(),blocked=new Set(current.obstacles);
   const initialAgentCells=new Set(v282EndpointFootprints(sc).filter(r=>r.kind==='INITIAL').flatMap(r=>r.cells.map(q=>q.join(','))));
   const zoneOK=q=>v26.validPoint(current,q)&&current.layer.robotZone.has(q.join(','))&&!blocked.has(q.join(','));
   const minSeparation=Math.max(7,Math.floor((current.W+current.H)/14));
   const all=prior.slice();let candidateNumber=0;
   for(const p of pool){
    if(created.length>=count)break;
    candidateNumber++;
    if(!zoneOK(p)){reject('DYNAMIC_ROUTE_INVALID');continue;}
    let route=[p.slice()],pos=p.slice();
    // Short one-way passages are intentional: once the moving hazard clears the area it exits.
    for(let segment=0;segment<2;segment++){
     const destinations=pool.filter(q=>zoneOK(q)&&Math.abs(q[0]-pos[0])+Math.abs(q[1]-pos[1])>=minSeparation);
     if(!destinations.length)break;
     let chosen=null;
     for(let attempt=0;attempt<25;attempt++){
      const target=destinations[Math.floor(rng()*destinations.length)];
      const path=v26.astar(current,pos,target,'R',{extra:zoneOK});
      if(path&&path.length>=minSeparation/2){chosen=path;break;}
     }
     if(!chosen)break;
     route.push(...chosen.slice(1).map(n=>n.p.slice()));pos=route.at(-1);
    }
    if(route.length<Math.max(12,minSeparation*2)){reject('DYNAMIC_ROUTE_INVALID');continue;}
    if(route.some((q,i)=>!zoneOK(q)||(i>0&&Math.abs(q[0]-route[i-1][0])+Math.abs(q[1]-route[i-1][1])!==1))){reject('DYNAMIC_ROUTE_INVALID');continue;}
    const interval=2;
    const duration=route.length*interval;
    // A deterministic full-timeline stream: finite routes with staggered recurring events.
    // Cycle is longer than a route; obstacles disappear between repetitions and never teleport.
    const repeatPeriod=Math.max(360,duration+100);
    const start=Math.floor(rng()*Math.max(1,repeatPeriod-duration));
    const item={id:'GD'+(current.dyn.length+created.length+1),start,path:route,duration,stepInterval:interval,repeatPeriod};
    if(start===0&&initialAgentCells.has(route[0].join(','))){reject('DYNAMIC_SPAWN_CONFLICT');continue;}
    const conflict=v282DynamicConflict(item,all);
    if(conflict){reject('DYNAMIC_SPAWN_CONFLICT');continue;}
    created.push(item);all.push(item);
   }
   if(created.length!==count)hazardError('DYNAMIC_HAZARD_GENERATION_FAILED',`requested=${count}, accepted=${created.length}, rejected=${JSON.stringify(rejections)}; no map changes committed`);
   // No imported dynamic hazard is modified, including legacy duration:null patrols.
   current.dyn.push(...created);
   generatedHazards.dynamic.push(...created.map(d=>d.id));
  }
  resetHazRun(true);
  $('hazStatus').textContent=`V28.4 ${type.toUpperCase()} accepted ${created.length}/${count} · rejected ${Object.values(rejections).reduce((a,b)=>a+b,0)} candidates · Seed ${$('hazSeed').value} · Scenario missions frozen`;
 }catch(e){$('hazStatus').textContent='GENERATION FAILED: '+e.message;console.error(e);}
}
$('makeStatic').onclick=()=>makeHazards('static');$('makeDynamic').onclick=()=>makeHazards('dynamic');
$('clearHazards').onclick=()=>{if(!current)return;for(const p of generatedHazards.static){let k=p.join(',');current.layer.staticObstacle.delete(k);current.obstacles.delete(k);}current.dyn=current.dyn.filter(d=>!generatedHazards.dynamic.includes(d.id));generatedHazards={static:[],dynamic:[]};resetHazRun();$('hazStatus').textContent='Cleared generated hazards. Imported obstacles remain intact.';};

