import csv,concurrent.futures,subprocess,json,time,pathlib,collections
root=pathlib.Path(__file__).parent
levels=['LOW','MED','HIGH'];cases=[]
for rule,haz in [('SR-009','none'),('SR-016','static'),('SR-018','static'),('SR-024','dynamic'),('SR-042','none')]:
 for level in levels:cases.append((f'E1-{len(cases)+1:02d}',level+'_BASIC',haz,rule))
for level in levels:cases.append((f'E1-{len(cases)+1:02d}',level+'_SR012','none','SR-012'))
for rules,haz,sr in [('SR-009+SR-042','none',False),('SR-009+SR-016+SR-018+SR-042','static',False),('SR-009+SR-024+SR-042','dynamic',False),('SR-009+SR-016+SR-018+SR-024+SR-042','staticdynamic',False),('SR-009+SR-016+SR-018+SR-024+SR-042+SR-012','staticdynamic',True)]:
 for level in levels:cases.append((f'E2-{len(cases)-17:02d}',level+('_SR012' if sr else '_BASIC'),haz,rules))
fields=['id','map','hazards','rules','status','wall_seconds','off','on','total','offTermination','onTermination','offDynContacts','onDynContacts','offAgentContacts','onAgentContacts','offCoverage','onCoverage','onEvents','onEventCodes','routeDifference','engine_ms','error','dynamicCount','staticCount']
def run(case):
 id,m,h,r=case; start=time.monotonic(); v={}
 try:
  p=subprocess.run(['node',str(root/'qa_runner_ready.js'),m,r,h],capture_output=True,text=True,timeout=48)
  v=json.loads(p.stdout.strip().splitlines()[-1]);
  if v.get('error'):status='ERROR'
  elif v['off']!=v['total'] or v['on']!=v['total'] or v['offTermination']!='COMPLETE' or v['onTermination']!='COMPLETE':status='FAIL_COMPLETION'
  elif 'dynamic' in h and (v['onCoverage']<.8 or v['offCoverage']<.8):status='FAIL_COVERAGE'
  elif v['onEvents']==0 or v['routeDifference']==0:status='NO_OBSERVED_RULE_EFFECT'
  elif 'dynamic' in h and v['onDynContacts']>=v['offDynContacts']:status='NO_DYNAMIC_CONTACT_REDUCTION'
  elif 'SR-042' in r and v['onAgentContacts']>=v['offAgentContacts']:status='NO_AGENT_CONTACT_REDUCTION'
  else:status='TECHNICAL_PASS_PROVISIONAL'
 except subprocess.TimeoutExpired:status='EXTERNAL_TIMEOUT_48S'
 except Exception as e:status='ERROR';v={'error':str(e)}
 row=dict.fromkeys(fields,'');row.update(id=id,map=m,hazards=h,rules=r,status=status,wall_seconds=round(time.monotonic()-start,2))
 for k in ['off','on','total','offTermination','onTermination','offDynContacts','onDynContacts','offAgentContacts','onAgentContacts','offCoverage','onCoverage','onEvents','onEventCodes','routeDifference']:
  if k in v:row[k]=json.dumps(v[k]) if isinstance(v[k],dict) else v[k]
 row['engine_ms']=v.get('ms','');row['error']=v.get('error','');row['dynamicCount']=v.get('hazardStat',{}).get('dyn','');row['staticCount']=v.get('hazardStat',{}).get('sta','');return row
results={}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 futures={pool.submit(run,c):c[0] for c in cases}
 for f in concurrent.futures.as_completed(futures):
  row=f.result();results[row['id']]=row
  print(row['id'],row['status'],row['off'],row['on'],row['onDynContacts'],flush=True)
  with open(root/'QA_33_READY_RETEST.csv','w',newline='') as out:
   w=csv.DictWriter(out,fieldnames=fields);w.writeheader();w.writerows([results[c[0]] for c in cases if c[0] in results])
print('SUMMARY',dict(collections.Counter(v['status'] for v in results.values())),flush=True)
