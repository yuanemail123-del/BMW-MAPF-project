# Warehouse Safety Simulator V28.5 — Final Freeze Engineering Prompt

Use the existing V28.4 standalone HTML as the sole authoritative implementation and retain the six maps, agent footprints, task generator, A*, six independently selectable rules, weights, eight reports, ZIP export, UI, persistent settings and reset controls. Restrict changes to SR-024 time-aware collision avoidance and the safety lifecycle of completed agents, together with necessary interfaces to existing SR-042 coordination. Do not invent new rule semantics, modify map geometry, skip tasks, teleport, suppress contacts or change scoring.

## P0: Reproduce before changing

Import the archived HIGH_SR012 experiment (Task Seed 1021, all six rules, 120 missions): OFF/ON 120/120 but ON dynamic contact pair-steps 12. Preserve its exact dynamic schedule, and identify FL02 at steps 1267–1272 (already completed 20/20 when GD2 arrives) and FL01 at steps 1274–1278 (`UNSAFE_WAIT_NO_ESCAPE` with GD2/GD4). Also reproduce LOW_BASIC SR-024 Task Seed 1001 and retain eight original reports. Do not conflate older V28.3 snapshots with V28.4 recurring schedules.

## P1: Completed-agent safe parking

Mission completion and physical presence are separate. After the final mission, keep agent `done` fixed (do not add any new mission) while the body continues to participate in collision prevention until the global simulation ends. Introduce `POST_MISSION_SAFE_HOLD` and `POST_MISSION_SAFE_EGRESS` as internal operational states; do not change completed mission counts. Finished agents must be checked by SR-024 and SR-042, including their full heading-dependent forklift footprints and swept turning areas. Select a valid parking position safe under the frozen future obstacle schedule; if an obstacle approaches, perform bounded legal evacuation. Do not call mission-goal route planners after `goalOf(agent)` becomes undefined. A safe parking spot must not permanently obstruct another active agent's mission or shared resource. If no safe motion exists, report failure; never disable a collision constraint.

## P2: Predictive SR-024

Retain the global A* path; add bounded time-expanded search (position, heading, timestep) for conflicting windows, starting at H=8 steps and reporting whether H is sufficient. Evaluate move, turn AND wait using identical transition legality: destination footprint at t+1, swept transition, dynamic obstacle occupancy at t/t+1, trajectory edge exchanges, zones, physical obstacles and SR-042 reservations when enabled. WAIT is a candidate action, not an automatically safe default. If risk exists in the next H steps, proactively find a safe temporary route or yielding cell, even when the immediate next A* action is legal. Avoid simply preferring progress to the mission goal at every lookahead step; account for future viability, not only next-step safety. Do not use a fixed safety buffer around walls. Do not generate threats in response to OFF/ON agent behavior.

## P3: Immutable recurring obstacles

Keep the V28.4 deterministic finite-lifetime repeating obstacle event stream generated from Hazard Seed; OFF and ON must share identical absolute-time occupancy and trajectory. Maintain the Low/Medium/High setting, finite concurrent population, legal obstacle paths and >=80% active temporal coverage for dynamic trials. Measure coverage over each actual run and the first/middle/last thirds, plus meaningful route conflict opportunities. Export sufficient schedule definitions in `scenario_config.json` for exact reconstruction. Do not hide collision failures by waiting for all hazards to vanish or choosing favorable seeds after observing ON.

## P4: Regression and research integrity

Run E1 18 and E2 15, using the existing random Mission Generator (NOT map default pairs), 20 missions/agent; maps LOW/MED/HIGH_BASIC use 80 missions and LOW/MED/HIGH_SR012 use 120. Task Seed=1001, Hazard Seed=1301, Low hazard density; TS=1, qR=qC=1, R=8, C=25, O=.12, W=.45. Preserve exactly the predefined E1/E2 matrix (as in `QA_33_CASES.csv`). Each OFF/ON pair must share the same frozen scenario; repeat identical seeds to check reproducibility.

Acceptance requires both OFF/ON COMPLETE, exact mission count, ON dynamic contacts zero whenever SR-024 is enabled; ON agent-agent contacts zero when SR-042 is enabled; no prohibited zone violations with SR-009; coverage>=80% when dynamics are present; no false completion, indefinite wait, scenario auto-substitution, or invalid interpolation. Distinguish `TIMEOUT` from `DEADLOCK` and show all failures, contact episodes and pair-steps, score subcomponents, path length, waiting and replanning. Review semantic rule abstraction against original Rulebook; a simplified 2D occupancy proxy cannot certify physical separation.

Every failed trial must be logged with first failure timestep, agent/mission, position/heading, obstacle IDs, next possible actions and why rejected; make minimal reasoned changes and rerun original snapshot plus affected tests. Save `QA_33_CASES.csv`, `QA_FAILURE_LOG.csv`, `QA_BEFORE_AFTER.csv`, `QA_DYNAMIC_COVERAGE.csv`, scripts, `CHANGELOG.md` and `VALIDATION.md`. Confirm eight individual exports exactly match the combined ZIP, offline HTML works in actual browser, localStorage preferences persist and reset works.

**Release gate**: only label `V28.5 FINAL — ACCEPTED` after ALL 33 randomized tests and manual browser checks pass. Otherwise mark `V28.5 CANDIDATE — NOT FULLY ACCEPTED`, list all failed/untested cases, and keep V28.4 as comparison baseline. Never fabricate or select results to reach the target.
